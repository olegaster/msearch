<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for mSearch.

1.4.0-beta
==============
- Added: direct pagination for the mSearch snippet via a new &offset property. The snippet now reads &offset and writes the total count into totalVar, so pdoPage can paginate it directly: {\'!pdoPage\' | snippet : [\'element\' => \'mSearch\', \'totalVar\' => \'page.total\', \'tpl\' => \'mSearch.row\', \'limit\' => 10]}. Previously mSearch ignored offset and pagination had to go through return=ids + pdoResources/msProducts (still required for miniShop3 products, which are rendered by msProducts). The [[+idx]] counter is now continuous across pages (starts at offset+1 on page 2).
- Added: &outputSeparator property on mSearch — separator between results for return=chunks (default \\n). The property is a single-line field, so \\n is inserted literally; use HTML (<hr>) for a visible separator, or &outputSeparator=`` to render results with no gap.
- Added: &log property on mSearch and a log option on Searcher::search() — disable writing the query to statistics (&log=`0`), e.g. for service-only return=ids calls.
- Changed: the manager UI now takes its theme from VueTools (modx/aura presets via the vuetools.theme system setting) instead of the Aura preset hardwired into the build. Requires VueTools 1.2.0+. Dark mode and the PrimeVue locale are inherited from VueTools; when a manager theme is active its variables apply.
- Changed: query statistics now log only a meaningful visitor query — a form submit (Enter or button) and the first page of results. Autocomplete suggestions (intermediate typing), pagination pages (2nd and beyond) and checks on the admin "Search" tab (manager context) no longer pollute the stats. A search finished by clicking a suggestion directly is not recorded.
- Changed: the client-side autocomplete threshold is taken from the mse_suggest_min_query_length setting. The snippet passes the value into window.msearchConfig; the data-min-query-length attribute on the form overrides it per case. Previously the client threshold was an independent constant of 2 that could diverge from the server one.
- Changed: search highlighting (<mark>) now carries the CSS class mse-highlight for styling. The class is configurable via options[\'tagOpen\'] in Highlighter.

1.3.3-beta
==============
- Added: TV output in autocomplete suggestions — &includeTVs / &tvPrefix on mSearchForm. One parameter works for both plain resources and products: ResourceAdapter loads via pdoFetch with includeTVs (raw rows, no object hydration), MsProductAdapter merges includeTVs into the msProducts snippet properties itself when &element is set. Chunk gets {$tvname} (highlighted) and {$tvname_raw} (raw). Values are read live — reindex is only needed to SEARCH by TV content, not to display it. tvPrefix is empty by default ({$color}).
- Added: &processTVs / &prepareTVs — pass pdoFetch TV rendering through (image/file media-source baseUrl, output filters). Rendered TVs are auto-excluded from highlighting (their value is a URL/HTML, not the searched text).
- Fixed: highlighting did not work for Cyrillic. Highlighter::buildPattern() and Searcher::processAliases() used /\\b...\\b/iu — the \\b word boundary is ASCII without (*UCP), so Russian words highlighted inconsistently and Cyrillic aliases with replace=1 never matched. Added (*UCP) to make \\w/\\b Unicode-aware.
- Fixed: admin "Search" tab showed an empty title column (only ID and Weight). SearchController::search() returned items without pagetitle while the Vue SearchPreview component expected it. The controller now adds a plain-text pagetitle and the admin table renders it as a link to the resource.

1.3.2-beta
==============
- Changed: Indexer::indexResource() now saves words via a single batch INSERT IGNORE per resource instead of N×xPDO save(). Fixes "Duplicate entry ... for key mse_words.PRIMARY" raised by parallel indexing passes (UI reindex racing with the on-save plugin, Scheduler racing with the plugin, etc.) — INSERT IGNORE drops the loser of the race, both passes produce identical rows from the same input. Also speeds up full reindex by 100-1000x on content-rich resources (round-trips collapse from per-word to per-resource). 500-row chunks keep individual statements below max_allowed_packet and prepared-statement parameter limits. Works identically on MySQL 5.7, MySQL 8.x, MariaDB 10.3+.
- Changed: Indexer::getStats() and Indexer::indexBatch() compute total via a single SQL count over modx_site_content instead of summing per-adapter getTotal(). The sum double-counted resources matched by multiple adapters (a product hits both ResourceAdapter and MsProductAdapter), inflating the admin "Total resources" card by 2x and the progress-bar denominator by the same factor. The new countIndexable() helper uses the shared filter (published, deleted, searchable) so the number matches reality; cache in msearch/indexer now holds one entry per criteria instead of per-adapter.

1.3.1-beta
==============
- Added: new &classKey property on mSearchForm — comma-separated class_keys to restrict search to one or more resource classes (e.g. MiniShop3\\Model\\msProduct). Filter is applied at the SQL level in mse_words and mse_intro, so weights and LIKE fallback are computed against the reduced set. Empty (default) keeps current behavior — no filter, all classes searched.
- Added: Searcher::search() now accepts a class_keys option (array or comma-separated string), exposed for direct PHP callers too.
- Changed: MsProductAdapter::enrich() now picks up price_formatted/old_price_formatted from msProducts when available (miniShop3 PR #269 contract). Falls back to number_format on raw float, then to verbatim string cast. Both old (pre-#269) and new miniShop3 behave correctly. Chunk mSearch.suggest.row keeps using {$price_display}, no template change required.
- Fixed: SearchController::chunkExists no longer rejects tpl values with binding prefixes (@FILE, @INLINE, @CHUNK). The block came from an earlier architecture where tpl could arrive from a client query — in 1.3.0+ it lives in MODX cache by formId, written exclusively by the on-page mSearchForm snippet (trusted source). Now constructs like &tpl=\'@FILE chunks/search/suggest.tpl\' work as expected.

1.3.0-beta2
==============
- Fixed: ResourceAdapter.getObjects/getTotal no longer applies a hard default filter class_key=modResource. In the intermediate 1.3.0-beta builds the filter discarded any resources whose class_key differs (modDocument both with and without namespace, custom modResource subclasses), and the index appeared empty after a fresh install. After the upgrade the existing data starts indexing without manual cache cleanup or repackage steps.

1.3.0-beta
==============
- Per-class adapter rendering for autocomplete and search results
- ContentAdapterInterface extended with getType(), getDisplayData(), getDefaultSuggestTpl(), getDefaultResultTpl()
- ResultSet now carries class_key per result; Searcher reads it from mse_words / mse_intro
- SearchController::suggest() and search() group results by class, batch-load via the right adapter, render each item via pdoTools::getChunk
- Service params (tpl, limit, ctx, element, elementProperties) configured via mSearchForm snippet properties, passed to API through MODX cache by formId — clients only send `query` / `offset` / `ctx` (closes SSTI vector)
- Highlighter::highlight() now escapes input before injecting <mark> — closes XSS via raw text in pagetitle (the new innerHTML pipeline made the pre-existing bug exploitable)
- Indexer::indexBatch dedupes IDs between adapters in one tick (avoids double indexing of msProduct)
- Indexer::indexBatch caches per-adapter getTotal() in MODX cache (10-min TTL)
- New system setting mse_suggest_min_query_length (default 2) — replaces hardcoded threshold in SearchController
- SearchUI.js drops stale autocomplete responses via request-sequence id
- AbstractAdapter::extractTvContent / flattenArray — promoted from duplicate methods in ResourceAdapter / MsProductAdapter
- AbstractAdapter::loadViaElement docblock notes trusted-source requirement
- Frontend autocomplete inserts pre-rendered HTML — no client-side templating
- New chunk mSearch.suggest.row (single template, branches by $type for product/resource)
- New mSearchForm properties: tplForm (form chunk), tpl (suggestion row chunk), limit, ctx
- New queryVar property (on both mSearchForm and mSearch) — customize the HTTP parameter name for the search query, default mse_query
- New element + elementProperties properties on mSearchForm — let the adapter load suggestion rows via an external snippet (e.g. ms3_products). Searcher still does the morphology/weight search; snippet just provides enriched per-id data. JSON-encoded extra properties are forwarded; resources/return are reserved
- New AbstractAdapter::loadViaElement() helper for adapters integrating with external snippets
- ContentAdapterInterface::getDisplayData() now accepts a third $options array; backwards-compatible default []
- New MsProductAdapter for miniShop3 — auto-registered when MiniShop3\\Model\\msProduct is available; indexes article and renders price/old_price/thumb
- New system setting mse_index_fields_product for tuning product index fields
- Indexer.indexBatch and getStats now iterate all registered adapters (was: first only — broke regular resource indexing once a second adapter joined)
- ResourceAdapter.getObjects/getTotal index all modResource subclasses (modDocument, msCategory, ...). Indexer routes each item to its specialized adapter via getAdapter() — items overlap between adapters is safe (re-indexing replaces prior entries)
- Indexer.getAdapter() and getAdaptersByType() promoted to IndexerInterface
- BREAKING: mSearchForm snippet property `tpl` previously meant "form template" — that role is now `tplForm`. New `tpl` means "autocomplete suggestion row template"

1.2.0-beta
==============
- New layered JS architecture: ApiClient, SearchAPI, Hooks, Headless entry point, SearchUI
- Headless mode (window.msearch) for React/Vue/custom integrations
- Hook system (msearchHooks) for extending search behavior: beforeSearch, afterSearch, beforeSuggest, afterSuggest, onError
- New public API endpoint (api.php) replacing web.php, with Router-based routing
- Context-aware search: filter results by MODX context via &contexts snippet parameter or ctx API parameter
- Rich API response: batch-loaded resources with pagetitle, longtitle, description, uri, full url, highlighted intro, weight
- Router: web/manager route separation via setContext(), flat response format {success, ...data}
- AbstractController base class for all API controllers
- mSearchForm snippet: passes ctx and connectorUrl as data-attributes, auto-registers JS in correct order
- CORS restricted to same-origin by default, configurable via mse_cors_origin system setting
- Removed web.php (replaced by api.php + Router)
- Fixed memory exhaustion (512MB) on search: Searcher and SearchController use raw PDO instead of xPDO objects to avoid object cache overhead with heavy models (msProduct)
- Fixed admin panel localization: Yes/No, Replace/Add, Cancel/Save/Install buttons use lexicon strings
- Fixed confirm dialog buttons using hardcoded English labels instead of lexicon
- Fixed PrimeIcons not loading in admin panel (missing CSS import)
- Fixed SearchPreview not displaying results (response format mismatch after API refactoring)

1.1.4-beta
==============
- Fixed "MySQL server has gone away" during package installation on servers with short connection timeouts (e.g. MariaDB 11.4). Added automatic database reconnect in resolvers after long file/network operations

1.1.3-beta
==============
- Fixed package uninstall failure: EncryptedVehicle class not found because MODX removes namespace directories before processing vehicles. Resolver now falls back to loading from package extract directory
- Fixed package uninstall blocked by decryption: EncryptedVehicle::uninstall() no longer fails when decryption key is unavailable, proceeds with resolver-based cleanup
- Synced VERSION constant in MSearch.php with package version

1.1.2-beta
==============
- Fixed autocomplete suggestions redirecting to search page instead of resource page
- Fixed file-based chunks (@FILE) not working in mSearchForm snippet
- Fixed snippet/plugin/chunk sources not updating on package upgrade

1.1.0-beta1
==============
- Added mseOnRegisterAdapters event for third-party adapter registration
- Fixed CSS box-sizing conflict with ExtJS/MODX interface

1.0.0-alpha2
==============
- Added VueTools dependency check with user-friendly error message
- Implemented Scheduler integration for background resource indexing

1.0.0-alpha1
==============
- Initial release for MODX 3.x
- Full-text search with word index
- Morphological analysis via phpMorphy (Russian, English, German)
- Search aliases (synonyms and replacements)
- Query statistics tracking
- Automatic resource indexing on save
- MODX Scheduler integration option
- Vue-based admin panel with VueTools
- Five admin tabs: Search, Index, Queries, Aliases, Dictionaries
- mSearch snippet for displaying results
- mSearchForm snippet with autocomplete support
- Frontend CSS/JS assets
- Custom events for extensibility (mseOnBeforeIndex, mseOnAfterIndex, mseOnBeforeSearch, mseOnAfterSearch, mseOnGetWorkFields)
',
    'license' => 'MIT License

Copyright (c) 2026 modx.pro

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '--------------------
mSearch
--------------------
Full-text search component for MODX Revolution 3.x
with morphological analysis support.
--------------------

Requirements:
- MODX Revolution 3.0+
- PHP 8.1+
- VueTools >= 1.2.0-pl (for admin panel)

Features:
- Morphological analysis (Russian, English, German)
- Word index with configurable field weights
- Search aliases (synonyms and replacements)
- Query statistics tracking
- Automatic indexing on resource save
- Vue-based admin panel
- Autocomplete support

Documentation:
https://docs.modx.pro/components/msearch

Issues and suggestions:
https://github.com/modx-pro/mSearch/issues
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '20595beefcb34b86c4f4c5c8087afaec',
      'native_key' => 'msearch',
      'filename' => 'MODX/Revolution/modNamespace/621f032f73f21f1f0e932b7446a394d3.vehicle',
      'namespace' => 'msearch',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '4171489745852e82941017013e553446',
      'native_key' => '4171489745852e82941017013e553446',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/72a9b6dbd34d414acd4ab083da80e75e.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'ce65f189ed9e22f19e7487c2dd30a51f',
      'native_key' => 'ce65f189ed9e22f19e7487c2dd30a51f',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/b0b2b7bfd6fd83ec15ce510d9c2959eb.vehicle',
      'namespace' => 'msearch',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'mSearch\\Transport\\EncryptedVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '55d259a9a74f9d2bda31083be21dc36e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/505170a71648cde68ccc67afb4882e28.vehicle',
      'namespace' => 'msearch',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '462bac7a61a4f93cb5ca670e95ae15c1',
      'native_key' => 'mse_index_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/83d28d92ae013843aeb7d13a9a322bb2.vehicle',
      'namespace' => 'msearch',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd845bc915c78a3631c986789eedce2e1',
      'native_key' => 'mse_index_fields_product',
      'filename' => 'MODX/Revolution/modSystemSetting/f3f5fb12e371c57437555cb6885e19fe.vehicle',
      'namespace' => 'msearch',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6c6aa1dd822915ff0351739b46ab6f9a',
      'native_key' => 'mse_index_min_word_length',
      'filename' => 'MODX/Revolution/modSystemSetting/0cee1731304ae155193003d26022d0ef.vehicle',
      'namespace' => 'msearch',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8628d3cccec80b14e0184aae9187e89b',
      'native_key' => 'mse_index_split_words',
      'filename' => 'MODX/Revolution/modSystemSetting/f420d564caf6f7e56696cdd6bb606b54.vehicle',
      'namespace' => 'msearch',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f1f969bafd0d124fd4324114ef151f03',
      'native_key' => 'mse_search_exact_match_bonus',
      'filename' => 'MODX/Revolution/modSystemSetting/d8050c04ead28754bf984eaf3e9ffd57.vehicle',
      'namespace' => 'msearch',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd49ae2793c0af63bc22ffd2e3f52e6ab',
      'native_key' => 'mse_search_like_match_bonus',
      'filename' => 'MODX/Revolution/modSystemSetting/ee113a6ad31ebb2bc19c97f3e1a67740.vehicle',
      'namespace' => 'msearch',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ea99f772f7b194d04e65017833b49b33',
      'native_key' => 'mse_search_all_words_bonus',
      'filename' => 'MODX/Revolution/modSystemSetting/0d72baf50903fe116e0c41976a342e2b.vehicle',
      'namespace' => 'msearch',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7c8835ffddf36d987d9b3994a9cbb96a',
      'native_key' => 'mse_search_split_words',
      'filename' => 'MODX/Revolution/modSystemSetting/971e49053b40085aad52152856994be6.vehicle',
      'namespace' => 'msearch',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2fcb9ab9a98b371894aaac5a925762bd',
      'native_key' => 'mse_suggest_min_query_length',
      'filename' => 'MODX/Revolution/modSystemSetting/070108d339a960c05149141278bc6919.vehicle',
      'namespace' => 'msearch',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2ac50c9ae214c812106497ec4443614e',
      'native_key' => 'mse_frontend_css',
      'filename' => 'MODX/Revolution/modSystemSetting/1df82cccd74ecfd3f7ab849196d435e0.vehicle',
      'namespace' => 'msearch',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6c36d0649ce9ff4a36168db2a2d9fbc2',
      'native_key' => 'mse_frontend_js',
      'filename' => 'MODX/Revolution/modSystemSetting/a74cf430d1d685b466744d988990a15e.vehicle',
      'namespace' => 'msearch',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1cd56c7768b989c23f57005576940dd6',
      'native_key' => 'mse_use_scheduler',
      'filename' => 'MODX/Revolution/modSystemSetting/99b5305e96bba4313bfd2b5306ca221e.vehicle',
      'namespace' => 'msearch',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'e1b03402fde42a606bbccc9477391531',
      'native_key' => 'msearch',
      'filename' => 'MODX/Revolution/modMenu/574ac5b1d2e0056cc4e0ffc8ec2bd0db.vehicle',
      'namespace' => 'msearch',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3458fc31bfe34d885a0b2c7fe0c04345',
      'native_key' => 'mseOnRegisterAdapters',
      'filename' => 'MODX/Revolution/modEvent/542ebb46db20959a96eb6820873cd4bd.vehicle',
      'namespace' => 'msearch',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1d9484289218d8cb0c3f35f114fa4137',
      'native_key' => 'mseOnBeforeIndex',
      'filename' => 'MODX/Revolution/modEvent/a9de252f3cd660f6d025921716cbc831.vehicle',
      'namespace' => 'msearch',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '32470cbed1325bd24e57bf0301b76bfb',
      'native_key' => 'mseOnAfterIndex',
      'filename' => 'MODX/Revolution/modEvent/33c6bb9666836b7da5bd35328d033f7e.vehicle',
      'namespace' => 'msearch',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b23dbd7f6835ae21328f09492c94a705',
      'native_key' => 'mseOnBeforeSearch',
      'filename' => 'MODX/Revolution/modEvent/8a79b1f16ff3b00df40c0aab8a0277c3.vehicle',
      'namespace' => 'msearch',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '109bdef94f5113311a6c72fef01ad477',
      'native_key' => 'mseOnAfterSearch',
      'filename' => 'MODX/Revolution/modEvent/2741917ce2d686759e50b37faaac2691.vehicle',
      'namespace' => 'msearch',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4ab24499594d6833d2f9ed4ae02df2df',
      'native_key' => 'mseOnGetWorkFields',
      'filename' => 'MODX/Revolution/modEvent/204a5051deb10a88b90897d1dce5ad55.vehicle',
      'namespace' => 'msearch',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'ecf3789e1fa4f677e82cfa2141e36480',
      'native_key' => 'ecf3789e1fa4f677e82cfa2141e36480',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/caf07314926df5694379c685f0670836.vehicle',
      'namespace' => 'msearch',
    ),
  ),
);
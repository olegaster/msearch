<?php
/**
 * mSearch Manager Controller
 */

use MODX\Revolution\modExtraManagerController;

require_once dirname(__FILE__, 3) . '/vendor/autoload.php';

class MSearchMgrHomeManagerController extends modExtraManagerController
{
    protected \MSearch\MSearch $msearch;

    /**
     * Флаг регистрации скрипта проверки VueTools (один раз на страницу)
     */
    protected static bool $vueToolsCheckRegistered = false;

    public function initialize(): void
    {
        $this->msearch = $this->modx->services->get('msearch');

        parent::initialize();
    }

    public function getPageTitle(): string
    {
        return $this->modx->lexicon('msearch');
    }

    public function getLanguageTopics(): array
    {
        return ['msearch:default'];
    }

    public function checkPermissions(): bool
    {
        return true;
    }

    public function loadCustomCssJs(): void
    {
        // CSS
        $this->addCss($this->cacheBust($this->msearch->config['cssUrl'] . 'mgr/main.css'));

        // Vue app CSS (from vue-dist)
        $this->addCss($this->cacheBust($this->msearch->config['cssUrl'] . 'mgr/vue-dist/msearch.min.css'));

        // Vue ES modules с проверкой наличия VueTools
        $this->addVueModule($this->msearch->config['jsUrl'] . 'mgr/vue-dist/msearch.min.js');

        // Config
        $this->addHtml('<script>
            window.mSearch = window.mSearch || {};
            mSearch.config = ' . json_encode($this->msearch->config) . ';
        </script>');
    }

    public function getTemplateFile(): string
    {
        return '';
    }

    public function process(array $scriptProperties = []): string
    {
        return '<div id="mse-manager-app" class="vueApp"></div>';
    }

    /**
     * Регистрация Vue ES module с проверкой зависимости VueTools
     *
     * @param string $src URL скрипта модуля
     * @return void
     */
    public function addVueModule(string $src): void
    {
        // Регистрируем скрипт проверки только один раз на страницу
        if (!self::$vueToolsCheckRegistered) {
            $this->registerVueToolsCheck();
            self::$vueToolsCheckRegistered = true;
        }

        // Добавляем версию + filemtime для сброса кэша: одной версии пакета
        // мало, т.к. при пересборке vue-dist под той же версией браузер держит
        // старый модуль. filemtime меняется при каждой пересборке.
        $src = $this->cacheBust($src);

        // Регистрируем модуль с атрибутом data-vue-module
        // Этот атрибут используется для удаления скриптов при отсутствии VueTools
        $this->modx->regClientStartupHTMLBlock(
            '<script type="module" data-vue-module src="' . $src . '"></script>'
        );
    }

    /**
     * Добавляет к URL ассета cache-bust: версия пакета + filemtime файла.
     * Без filemtime браузер держит старый vue-dist при пересборке под той же
     * версией пакета.
     */
    protected function cacheBust(string $src): string
    {
        $version = \MSearch\MSearch::VERSION;
        $assetsUrl = rtrim((string) $this->msearch->config['assetsUrl'], '/');
        $assetsPath = rtrim((string) $this->msearch->config['assetsPath'], '/');
        if ($assetsUrl !== '' && str_starts_with($src, $assetsUrl)) {
            $fsPath = $assetsPath . substr($src, strlen($assetsUrl));
            if (is_file($fsPath)) {
                $version .= '.' . filemtime($fsPath);
            }
        }
        $separator = str_contains($src, '?') ? '&' : '?';
        return $src . $separator . 'v=' . rawurlencode($version);
    }

    /**
     * Регистрация inline скрипта проверки Import Map
     * Если VueTools не установлен — показывает MODX алерт
     */
    protected function registerVueToolsCheck(): void
    {
        // Используем лексиконы компонента
        $alertTitle = $this->modx->lexicon('mse_error') ?: 'Error';
        $alertMessage = $this->modx->lexicon('mse_vuetools_required')
            ?: 'VueTools package is required. Please install it from Package Manager.';

        $script = <<<JS
<script>
(function() {
    // Ищем Import Map с ключом vue
    var importMap = document.querySelector('script[type="importmap"]');
    var hasVueTools = false;

    if (importMap) {
        try {
            var mapContent = JSON.parse(importMap.textContent);
            // Ключ vuetools/theme есть только в сборках VueTools со
            // @vuetools/useTheme (>= 1.2.0). Так проверяем и наличие, и версию:
            // старая VueTools без темы не пройдёт.
            hasVueTools = mapContent.imports
                && mapContent.imports.vue
                && mapContent.imports['vuetools/theme'];
        } catch (e) {
            hasVueTools = false;
        }
    }

    // Если VueTools не найден — удаляем Vue модули и показываем алерт
    if (!hasVueTools) {
        // Удаляем все скрипты с атрибутом data-vue-module
        document.querySelectorAll('script[type="module"][data-vue-module]').forEach(function(el) {
            el.remove();
        });

        // Показываем MODX алерт (ждём загрузки ExtJS)
        if (typeof Ext !== 'undefined') {
            Ext.onReady(function() {
                if (typeof MODx !== 'undefined' && MODx.msg) {
                    MODx.msg.alert('{$alertTitle}', '{$alertMessage}');
                } else {
                    alert('{$alertMessage}');
                }
            });
        } else {
            document.addEventListener('DOMContentLoaded', function() {
                setTimeout(function() {
                    if (typeof MODx !== 'undefined' && MODx.msg) {
                        MODx.msg.alert('{$alertTitle}', '{$alertMessage}');
                    } else {
                        alert('{$alertMessage}');
                    }
                }, 500);
            });
        }

        // Глобальный флаг для использования в других скриптах
        window.MSE_VUE_TOOLS_MISSING = true;
    }
})();
</script>
JS;

        $this->modx->regClientStartupHTMLBlock($script);
    }
}

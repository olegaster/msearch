<?php

namespace MSearch\Model;

use xPDO\Om\xPDOSimpleObject;

/**
 * Search query statistics
 *
 * @property int $id
 * @property string $query
 * @property int $count
 * @property int $results
 * @property bool $found
 * @property string $created_at
 * @property string $updated_at
 */
class MseQuery extends xPDOSimpleObject
{
}

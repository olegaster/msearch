<?php

namespace MSearch\Model;

use MODX\Revolution\modResource;
use xPDO\Om\xPDOObject;

/**
 * Word index entity
 *
 * @property int $resource
 * @property string $field
 * @property string $word
 * @property int $count
 * @property string $class_key
 */
class MseWord extends xPDOObject
{
}

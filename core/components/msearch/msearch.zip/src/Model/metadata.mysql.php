<?php

$xpdo_meta_map = [
    'version' => '3.0',
    'namespace' => 'MSearch\\Model',
    'namespacePrefix' => 'MSearch',
    'class_map' => [
        'xPDO\\Om\\xPDOObject' => [
            'MSearch\\Model\\MseWord',
            'MSearch\\Model\\MseIntro',
            'MSearch\\Model\\MseQuery',
            'MSearch\\Model\\MseAlias',
        ],
    ],
];

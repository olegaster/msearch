<?php

namespace MSearch\Model;

use xPDO\Om\xPDOObject;

/**
 * Full text intro for LIKE search and highlighting
 *
 * @property int $resource
 * @property string $intro
 * @property string $class_key
 */
class MseIntro extends xPDOObject
{
}

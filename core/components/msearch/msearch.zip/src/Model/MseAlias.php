<?php

namespace MSearch\Model;

use xPDO\Om\xPDOSimpleObject;

/**
 * Search aliases (synonyms)
 *
 * @property int $id
 * @property string $word
 * @property string $alias
 * @property bool $replace
 * @property bool $active
 */
class MseAlias extends xPDOSimpleObject
{
}

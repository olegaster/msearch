<?php

namespace MSearch\Model\mysql;

use xPDO\xPDO;

class MseAlias extends \MSearch\Model\MseAlias
{
    public static $metaMap = [
        'package' => 'MSearch\\Model',
        'version' => '3.0',
        'table' => 'mse_aliases',
        'extends' => 'xPDO\\Om\\xPDOSimpleObject',
        'tableMeta' => [
            'engine' => 'InnoDB',
        ],
        'fields' => [
            'id' => null,
            'word' => null,
            'alias' => null,
            'replace' => 0,
            'active' => 1,
        ],
        'fieldMeta' => [
            'id' => [
                'dbtype' => 'int',
                'precision' => '10',
                'phptype' => 'integer',
                'attributes' => 'unsigned',
                'null' => false,
                'index' => 'pk',
                'generated' => 'native',
            ],
            'word' => [
                'dbtype' => 'varchar',
                'precision' => '100',
                'phptype' => 'string',
                'null' => false,
                'index' => 'index',
            ],
            'alias' => [
                'dbtype' => 'varchar',
                'precision' => '100',
                'phptype' => 'string',
                'null' => false,
            ],
            'replace' => [
                'dbtype' => 'tinyint',
                'precision' => '1',
                'phptype' => 'boolean',
                'null' => false,
                'default' => 0,
            ],
            'active' => [
                'dbtype' => 'tinyint',
                'precision' => '1',
                'phptype' => 'boolean',
                'null' => false,
                'default' => 1,
                'index' => 'index',
            ],
        ],
        'indexes' => [
            'PRIMARY' => [
                'alias' => 'PRIMARY',
                'primary' => true,
                'unique' => true,
                'type' => 'BTREE',
                'columns' => [
                    'id' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
            'idx_word' => [
                'alias' => 'idx_word',
                'primary' => false,
                'unique' => false,
                'type' => 'BTREE',
                'columns' => [
                    'word' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
            'idx_active' => [
                'alias' => 'idx_active',
                'primary' => false,
                'unique' => false,
                'type' => 'BTREE',
                'columns' => [
                    'active' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
        ],
    ];
}

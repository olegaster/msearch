<?php

namespace MSearch\Model\mysql;

use xPDO\xPDO;

class MseIntro extends \MSearch\Model\MseIntro
{
    public static $metaMap = [
        'package' => 'MSearch\\Model',
        'version' => '3.0',
        'table' => 'mse_intro',
        'extends' => 'xPDO\\Om\\xPDOObject',
        'tableMeta' => [
            'engine' => 'InnoDB',
        ],
        'fields' => [
            'resource' => null,
            'intro' => null,
            'class_key' => 'MODX\\Revolution\\modResource',
        ],
        'fieldMeta' => [
            'resource' => [
                'dbtype' => 'int',
                'precision' => '10',
                'phptype' => 'integer',
                'attributes' => 'unsigned',
                'null' => false,
                'index' => 'pk',
            ],
            'intro' => [
                'dbtype' => 'mediumtext',
                'phptype' => 'string',
                'null' => false,
            ],
            'class_key' => [
                'dbtype' => 'varchar',
                'precision' => '100',
                'phptype' => 'string',
                'null' => false,
                'default' => 'MODX\\Revolution\\modResource',
                'index' => 'pk',
            ],
        ],
        'indexes' => [
            'PRIMARY' => [
                'alias' => 'PRIMARY',
                'primary' => true,
                'unique' => true,
                'type' => 'BTREE',
                'columns' => [
                    'resource' => ['length' => '', 'collation' => 'A', 'null' => false],
                    'class_key' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
        ],
        'composites' => [
            'Words' => [
                'class' => 'MSearch\\Model\\MseWord',
                'local' => 'resource',
                'foreign' => 'resource',
                'owner' => 'local',
                'cardinality' => 'many',
            ],
        ],
        'aggregates' => [
            'Resource' => [
                'class' => 'MODX\\Revolution\\modResource',
                'local' => 'resource',
                'foreign' => 'id',
                'owner' => 'foreign',
                'cardinality' => 'one',
            ],
        ],
    ];
}

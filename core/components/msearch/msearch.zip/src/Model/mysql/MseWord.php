<?php

namespace MSearch\Model\mysql;

use xPDO\xPDO;

class MseWord extends \MSearch\Model\MseWord
{
    public static $metaMap = [
        'package' => 'MSearch\\Model',
        'version' => '3.0',
        'table' => 'mse_words',
        'extends' => 'xPDO\\Om\\xPDOObject',
        'tableMeta' => [
            'engine' => 'InnoDB',
        ],
        'fields' => [
            'resource' => null,
            'field' => null,
            'word' => null,
            'count' => 1,
            'class_key' => 'MODX\\Revolution\\modResource',
        ],
        'fieldMeta' => [
            'resource' => [
                'dbtype' => 'int',
                'precision' => '10',
                'phptype' => 'integer',
                'attributes' => 'unsigned',
                'null' => false,
                'index' => 'pk',
            ],
            'field' => [
                'dbtype' => 'varchar',
                'precision' => '50',
                'phptype' => 'string',
                'null' => false,
                'index' => 'pk',
            ],
            'word' => [
                'dbtype' => 'varchar',
                'precision' => '32',
                'phptype' => 'string',
                'null' => false,
                'index' => 'pk',
            ],
            'count' => [
                'dbtype' => 'int',
                'precision' => '10',
                'phptype' => 'integer',
                'attributes' => 'unsigned',
                'null' => false,
                'default' => 1,
            ],
            'class_key' => [
                'dbtype' => 'varchar',
                'precision' => '100',
                'phptype' => 'string',
                'null' => false,
                'default' => 'MODX\\Revolution\\modResource',
                'index' => 'pk',
            ],
        ],
        'indexes' => [
            'PRIMARY' => [
                'alias' => 'PRIMARY',
                'primary' => true,
                'unique' => true,
                'type' => 'BTREE',
                'columns' => [
                    'resource' => ['length' => '', 'collation' => 'A', 'null' => false],
                    'field' => ['length' => '', 'collation' => 'A', 'null' => false],
                    'word' => ['length' => '', 'collation' => 'A', 'null' => false],
                    'class_key' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
            'idx_word' => [
                'alias' => 'idx_word',
                'primary' => false,
                'unique' => false,
                'type' => 'BTREE',
                'columns' => [
                    'word' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
            'idx_resource' => [
                'alias' => 'idx_resource',
                'primary' => false,
                'unique' => false,
                'type' => 'BTREE',
                'columns' => [
                    'resource' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
        ],
        'aggregates' => [
            'Resource' => [
                'class' => 'MODX\\Revolution\\modResource',
                'local' => 'resource',
                'foreign' => 'id',
                'owner' => 'foreign',
                'cardinality' => 'one',
            ],
        ],
    ];
}

<?php

namespace MSearch\Model\mysql;

use xPDO\xPDO;

class MseQuery extends \MSearch\Model\MseQuery
{
    public static $metaMap = [
        'package' => 'MSearch\\Model',
        'version' => '3.0',
        'table' => 'mse_queries',
        'extends' => 'xPDO\\Om\\xPDOSimpleObject',
        'tableMeta' => [
            'engine' => 'InnoDB',
        ],
        'fields' => [
            'id' => null,
            'query' => null,
            'count' => 1,
            'results' => 0,
            'found' => true,
            'created_at' => null,
            'updated_at' => null,
        ],
        'fieldMeta' => [
            'id' => [
                'dbtype' => 'int',
                'precision' => '10',
                'phptype' => 'integer',
                'attributes' => 'unsigned',
                'null' => false,
                'index' => 'pk',
                'generated' => 'native',
            ],
            'query' => [
                'dbtype' => 'varchar',
                'precision' => '255',
                'phptype' => 'string',
                'null' => false,
                'index' => 'unique',
            ],
            'count' => [
                'dbtype' => 'int',
                'precision' => '10',
                'phptype' => 'integer',
                'attributes' => 'unsigned',
                'null' => false,
                'default' => 1,
            ],
            'results' => [
                'dbtype' => 'int',
                'precision' => '10',
                'phptype' => 'integer',
                'attributes' => 'unsigned',
                'null' => false,
                'default' => 0,
            ],
            'found' => [
                'dbtype' => 'tinyint',
                'precision' => '1',
                'phptype' => 'boolean',
                'null' => false,
                'default' => true,
            ],
            'created_at' => [
                'dbtype' => 'datetime',
                'phptype' => 'datetime',
                'null' => false,
            ],
            'updated_at' => [
                'dbtype' => 'datetime',
                'phptype' => 'datetime',
                'null' => true,
            ],
        ],
        'indexes' => [
            'PRIMARY' => [
                'alias' => 'PRIMARY',
                'primary' => true,
                'unique' => true,
                'type' => 'BTREE',
                'columns' => [
                    'id' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
            'idx_query' => [
                'alias' => 'idx_query',
                'primary' => false,
                'unique' => true,
                'type' => 'BTREE',
                'columns' => [
                    'query' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
            'idx_count' => [
                'alias' => 'idx_count',
                'primary' => false,
                'unique' => false,
                'type' => 'BTREE',
                'columns' => [
                    'count' => ['length' => '', 'collation' => 'A', 'null' => false],
                ],
            ],
        ],
    ];
}

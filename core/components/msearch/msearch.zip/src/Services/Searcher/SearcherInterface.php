<?php

namespace MSearch\Services\Searcher;

/**
 * Searcher service interface
 */
interface SearcherInterface
{
    /**
     * Search for resources by query
     */
    public function search(string $query, array $options = []): ResultSet;
}

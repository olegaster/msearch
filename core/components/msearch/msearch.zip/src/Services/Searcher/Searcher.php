<?php

namespace MSearch\Services\Searcher;

use MODX\Revolution\modX;
use MSearch\Model\MseAlias;
use MSearch\Model\MseIntro;
use MSearch\Model\MseQuery;
use MSearch\Model\MseWord;
use MSearch\MSearch;

/**
 * Search service
 */
class Searcher implements SearcherInterface
{
    protected modX $modx;
    protected MSearch $msearch;

    protected string $splitPattern;
    protected int $exactMatchBonus;
    protected int $likeMatchBonus;
    protected int $allWordsBonus;

    public function __construct(modX $modx, MSearch $msearch)
    {
        $this->modx = $modx;
        $this->msearch = $msearch;

        $this->splitPattern = $modx->getOption('mse_search_split_words', null, '#\s+#u');
        $this->exactMatchBonus = (int) $modx->getOption('mse_search_exact_match_bonus', null, 10);
        $this->likeMatchBonus = (int) $modx->getOption('mse_search_like_match_bonus', null, 3);
        $this->allWordsBonus = (int) $modx->getOption('mse_search_all_words_bonus', null, 5);
    }

    /**
     * Search for resources
     */
    public function search(string $query, array $options = []): ResultSet
    {
        $query = trim($query);
        if (empty($query)) {
            return new ResultSet();
        }

        // Fire before event
        $this->modx->invokeEvent('mseOnBeforeSearch', [
            'query' => &$query,
            'options' => &$options,
        ]);

        // Process aliases
        $query = $this->processAliases($query);

        // Split query into words
        $words = $this->splitQuery($query);
        if (empty($words)) {
            return new ResultSet();
        }

        // Get base forms for each word
        $searchWords = [];
        foreach ($words as $word) {
            $baseForms = $this->msearch->getMorphology()->getBaseForms($word);
            if (empty($baseForms)) {
                $baseForms = [$word];
            }
            $searchWords[$word] = $baseForms;
        }

        // Get field weights from settings
        $fieldWeights = $this->getFieldWeights();

        // Context filtering
        $contexts = $options['contexts'] ?? [];
        if (is_string($contexts)) {
            $contexts = array_filter(array_map('trim', explode(',', $contexts)));
        }

        // class_key filtering (optional). Empty array = no filter, every class_key passes through.
        $classKeys = $options['class_keys'] ?? [];
        if (is_string($classKeys)) {
            $classKeys = array_filter(array_map('trim', explode(',', $classKeys)));
        }
        $classKeys = array_values(array_filter(array_map('strval', (array) $classKeys)));

        // Search in index
        $classes = [];
        $results = $this->searchInIndex($searchWords, $fieldWeights, $contexts, $classes, $classKeys);

        // LIKE fallback for words not found in index
        $results = $this->likeFallback($results, $searchWords, $query, $contexts, $classes, $classKeys);

        // Apply bonuses
        $results = $this->applyBonuses($results, $words, $query);

        // Стабильный порядок: вес по убыванию, при равенстве — id по возрастанию.
        $this->sortByWeightStable($results);

        // Log query statistics. Пропускаем, когда вызывающий отключил логирование
        // (автоподсказки, админ-превью, страницы пагинации 2+). filter_var — чтобы
        // '0'/0/'' от плагина или свойства сниппета тоже отключали, а не только
        // строгий false.
        if (filter_var($options['log'] ?? true, FILTER_VALIDATE_BOOLEAN)) {
            $this->logQuery($query, count($results));
        }

        // Create result set
        $resultSet = new ResultSet($results, $query, count($results), $classes);

        // Apply pagination
        $limit = $options['limit'] ?? 10;
        $offset = $options['offset'] ?? 0;

        if ($limit > 0 || $offset > 0) {
            $resultSet = $resultSet->slice($offset, $limit);
        }

        // Fire after event
        $this->modx->invokeEvent('mseOnAfterSearch', [
            'query' => $query,
            'results' => $resultSet,
        ]);

        return $resultSet;
    }

    /**
     * Process aliases in query
     */
    protected function processAliases(string $query): string
    {
        $c = $this->modx->newQuery(MseAlias::class);
        $c->where(['active' => true]);

        foreach ($this->modx->getIterator(MseAlias::class, $c) as $alias) {
            $word = $alias->get('word');
            $replacement = $alias->get('alias');
            $replace = $alias->get('replace');

            if ($replace) {
                // Replace word completely. (*UCP) makes \b Unicode-aware — without
                // it the ASCII word boundary never matches Cyrillic aliases, so
                // replace=1 was a no-op for Russian words (the common case).
                $query = preg_replace('/(*UCP)\b' . preg_quote($word, '/') . '\b/iu', $replacement, $query);
            } else {
                // Add synonym
                if (stripos($query, $word) !== false) {
                    $query .= ' ' . $replacement;
                }
            }
        }

        return $query;
    }

    /**
     * Split query into words
     */
    protected function splitQuery(string $query): array
    {
        $query = mb_strtolower($query, 'UTF-8');
        $parts = preg_split($this->splitPattern, $query, -1, PREG_SPLIT_NO_EMPTY);

        $minLength = (int) $this->modx->getOption('mse_index_min_word_length', null, 3);

        return array_filter($parts, fn($word) => mb_strlen(trim($word), 'UTF-8') >= $minLength);
    }

    /**
     * Get field weights from settings
     */
    protected function getFieldWeights(): array
    {
        $fields = $this->modx->getOption(
            'mse_index_fields',
            null,
            'pagetitle:3,longtitle:2,description:2,introtext:2,content:1'
        );

        $result = [];
        foreach (explode(',', $fields) as $part) {
            if (str_contains($part, ':')) {
                [$field, $weight] = explode(':', trim($part), 2);
                $result[trim($field)] = (int) $weight;
            }
        }

        return $result;
    }

    /**
     * Search in word index (raw PDO — no xPDO object overhead)
     *
     * @param array<int,string> $classes Output: [resource_id => class_key]
     * @param string[] $classKeys Optional filter — restrict index lookup to these class_keys
     */
    protected function searchInIndex(array $searchWords, array $fieldWeights, array $contexts = [], array &$classes = [], array $classKeys = []): array
    {
        $results = [];
        $wordTable = $this->modx->getTableName(MseWord::class);

        foreach ($searchWords as $originalWord => $baseForms) {
            $placeholders = implode(',', array_fill(0, count($baseForms), '?'));
            $params = array_values($baseForms);

            $sql = "SELECT w.`resource`, w.`field`, w.`count`, w.`class_key` FROM {$wordTable} w";

            if (!empty($contexts)) {
                $resourceTable = $this->modx->getTableName(\MODX\Revolution\modResource::class);
                $ctxPlaceholders = implode(',', array_fill(0, count($contexts), '?'));
                $sql .= " INNER JOIN {$resourceTable} r ON w.`resource` = r.`id`";
                $sql .= " WHERE w.`word` IN ({$placeholders}) AND r.`context_key` IN ({$ctxPlaceholders})";
                $params = array_merge($params, $contexts);
            } else {
                $sql .= " WHERE w.`word` IN ({$placeholders})";
            }

            if (!empty($classKeys)) {
                $classPlaceholders = implode(',', array_fill(0, count($classKeys), '?'));
                $sql .= " AND w.`class_key` IN ({$classPlaceholders})";
                $params = array_merge($params, $classKeys);
            }

            $stmt = $this->modx->prepare($sql);
            if ($stmt && $stmt->execute($params)) {
                while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                    $resourceId = (int) $row['resource'];
                    $field = $row['field'];
                    $count = (int) $row['count'];
                    $classKey = $row['class_key'] ?? '';

                    $weight = $fieldWeights[$field] ?? 1;
                    $score = $count * $weight;

                    if (!isset($results[$resourceId])) {
                        $results[$resourceId] = 0;
                    }
                    $results[$resourceId] += $score;

                    if (!empty($classKey) && !isset($classes[$resourceId])) {
                        $classes[$resourceId] = $classKey;
                    }
                }
                $stmt->closeCursor();
            }
        }

        return $results;
    }

    /**
     * LIKE fallback for words not in index (raw PDO)
     *
     * @param array<int,string> $classes Output: [resource_id => class_key]
     * @param string[] $classKeys Optional filter — restrict LIKE fallback to these class_keys
     */
    protected function likeFallback(array $results, array $searchWords, string $query, array $contexts = [], array &$classes = [], array $classKeys = []): array
    {
        $introTable = $this->modx->getTableName(MseIntro::class);
        $params = ['%' . $query . '%'];

        $sql = "SELECT i.`resource`, i.`class_key` FROM {$introTable} i";

        if (!empty($contexts)) {
            $resourceTable = $this->modx->getTableName(\MODX\Revolution\modResource::class);
            $ctxPlaceholders = implode(',', array_fill(0, count($contexts), '?'));
            $sql .= " INNER JOIN {$resourceTable} r ON i.`resource` = r.`id`";
            $sql .= " WHERE i.`intro` LIKE ? AND r.`context_key` IN ({$ctxPlaceholders})";
            $params = array_merge($params, $contexts);
        } else {
            $sql .= " WHERE i.`intro` LIKE ?";
        }

        if (!empty($classKeys)) {
            $classPlaceholders = implode(',', array_fill(0, count($classKeys), '?'));
            $sql .= " AND i.`class_key` IN ({$classPlaceholders})";
            $params = array_merge($params, $classKeys);
        }

        // Детерминированный отбор: без ORDER BY при >1000 совпадений состав
        // и общее число плавали бы от запроса к запросу.
        $sql .= " ORDER BY i.`resource` LIMIT 1000";

        $stmt = $this->modx->prepare($sql);
        if ($stmt && $stmt->execute($params)) {
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $resourceId = (int) $row['resource'];
                $classKey = $row['class_key'] ?? '';

                if (!isset($results[$resourceId])) {
                    $results[$resourceId] = $this->likeMatchBonus;
                } else {
                    $results[$resourceId] += $this->likeMatchBonus;
                }

                if (!empty($classKey) && !isset($classes[$resourceId])) {
                    $classes[$resourceId] = $classKey;
                }
            }
            $stmt->closeCursor();
        }

        return $results;
    }

    /**
     * Стабильная сортировка результатов на месте: вес по убыванию, при равных
     * весах — id по возрастанию. Детерминированный порядок между запросами —
     * без него пагинация «плавает» при одинаковых весах (дубли и пропуски).
     *
     * @param array<int,float> $results [id => weight]
     */
    private function sortByWeightStable(array &$results): void
    {
        uksort($results, static function ($a, $b) use ($results) {
            return ($results[$b] <=> $results[$a]) ?: ($a <=> $b);
        });
    }

    /**
     * Apply search bonuses (streaming — one row at a time, no bulk loading)
     */
    protected function applyBonuses(array $results, array $words, string $query): array
    {
        if (empty($results)) {
            return $results;
        }

        // Limit bonus calculation to top results only
        $maxBonusResults = 100;
        $resourceIds = array_keys($results);

        if (count($resourceIds) > $maxBonusResults) {
            // Тот же стабильный порядок, что и в итоговой сортировке, — иначе
            // на границе топ-100 бонус достаётся то одному, то другому ресурсу
            // с равным весом, и позиции плывут между страницами.
            $this->sortByWeightStable($results);
            $resourceIds = array_slice(array_keys($results), 0, $maxBonusResults);
        }

        $queryLower = mb_strtolower($query, 'UTF-8');

        // Stream intros one at a time to avoid loading all mediumtext into memory
        $introTable = $this->modx->getTableName(MseIntro::class);
        $placeholders = implode(',', array_fill(0, count($resourceIds), '?'));
        $sql = "SELECT `resource`, `intro` FROM {$introTable} WHERE `resource` IN ({$placeholders})";

        $stmt = $this->modx->prepare($sql);
        if ($stmt && $stmt->execute($resourceIds)) {
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $resourceId = (int) $row['resource'];
                $introText = mb_strtolower($row['intro'], 'UTF-8');

                // Exact match bonus
                if (str_contains($introText, $queryLower)) {
                    $results[$resourceId] += $this->exactMatchBonus;
                }

                // All words bonus
                $allFound = true;
                foreach ($words as $word) {
                    if (!str_contains($introText, $word)) {
                        $allFound = false;
                        break;
                    }
                }
                if ($allFound) {
                    $results[$resourceId] += $this->allWordsBonus;
                }

                unset($introText);
            }
            $stmt->closeCursor();
        }

        return $results;
    }

    /**
     * Log search query for statistics
     */
    protected function logQuery(string $query, int $resultsCount): void
    {
        $existing = $this->modx->getObject(MseQuery::class, ['query' => $query]);

        if ($existing) {
            $existing->set('count', $existing->get('count') + 1);
            $existing->set('results', $resultsCount);
            $existing->set('found', $resultsCount > 0);
            $existing->save();
        } else {
            $mseQuery = $this->modx->newObject(MseQuery::class);
            $mseQuery->set('query', $query);
            $mseQuery->set('count', 1);
            $mseQuery->set('results', $resultsCount);
            $mseQuery->set('found', $resultsCount > 0);
            $mseQuery->set('created_at', date('Y-m-d H:i:s'));
            $mseQuery->save();
        }
    }
}

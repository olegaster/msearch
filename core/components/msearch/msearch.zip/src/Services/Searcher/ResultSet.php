<?php

namespace MSearch\Services\Searcher;

use ArrayIterator;
use Countable;
use IteratorAggregate;
use Traversable;

/**
 * Search results collection
 *
 * Contains resource IDs with their weights and class_keys, sorted by relevance
 */
class ResultSet implements Countable, IteratorAggregate
{
    /**
     * Results array [resource_id => weight]
     */
    protected array $results = [];

    /**
     * Class keys map [resource_id => class_key]
     */
    protected array $classes = [];

    /**
     * Original query
     */
    protected string $query = '';

    /**
     * Total count before pagination
     */
    protected int $total = 0;

    public function __construct(array $results = [], string $query = '', int $total = 0, array $classes = [])
    {
        $this->results = $results;
        $this->classes = $classes;
        $this->query = $query;
        $this->total = $total ?: count($results);
    }

    /**
     * Get all results as array [resource_id => weight]
     */
    public function toArray(): array
    {
        return $this->results;
    }

    /**
     * Get resource IDs only
     */
    public function getIds(): array
    {
        return array_keys($this->results);
    }

    /**
     * Get weight for specific resource
     */
    public function getWeight(int $resourceId): float
    {
        return $this->results[$resourceId] ?? 0.0;
    }

    /**
     * Get class_key for specific resource
     */
    public function getClassKey(int $resourceId): ?string
    {
        return $this->classes[$resourceId] ?? null;
    }

    /**
     * Get full classes map [resource_id => class_key]
     */
    public function getClasses(): array
    {
        return $this->classes;
    }

    /**
     * Set class_key for specific resource
     */
    public function setClassKey(int $resourceId, string $classKey): void
    {
        $this->classes[$resourceId] = $classKey;
    }

    /**
     * Group resource IDs by class_key
     *
     * @return array<string, int[]> [class_key => [id, id, ...]]
     */
    public function groupByClass(): array
    {
        $grouped = [];
        foreach (array_keys($this->results) as $id) {
            $class = $this->classes[$id] ?? '';
            $grouped[$class][] = $id;
        }
        return $grouped;
    }

    /**
     * Check if resource is in results
     */
    public function has(int $resourceId): bool
    {
        return isset($this->results[$resourceId]);
    }

    /**
     * Get the search query
     */
    public function getQuery(): string
    {
        return $this->query;
    }

    /**
     * Get total count (before pagination)
     */
    public function getTotal(): int
    {
        return $this->total;
    }

    /**
     * Count results
     */
    public function count(): int
    {
        return count($this->results);
    }

    /**
     * Check if empty
     */
    public function isEmpty(): bool
    {
        return empty($this->results);
    }

    /**
     * Get iterator
     */
    public function getIterator(): Traversable
    {
        return new ArrayIterator($this->results);
    }

    /**
     * Sort by weight descending
     */
    public function sortByWeight(): self
    {
        arsort($this->results);
        return $this;
    }

    /**
     * Slice results for pagination
     */
    public function slice(int $offset, int $limit): self
    {
        // Отрицательный offset в array_slice отсчитывается с конца —
        // клиентское значение из API могло бы вернуть «хвост» вместо первой
        // страницы. Клампим снизу нулём во всех точках входа.
        $offset = max(0, $offset);
        $sliced = array_slice($this->results, $offset, $limit > 0 ? $limit : null, true);
        $classes = array_intersect_key($this->classes, $sliced);
        return new self($sliced, $this->query, $this->total, $classes);
    }

    /**
     * Merge with another result set
     */
    public function merge(ResultSet $other): self
    {
        foreach ($other->toArray() as $id => $weight) {
            if (isset($this->results[$id])) {
                $this->results[$id] += $weight;
            } else {
                $this->results[$id] = $weight;
            }
        }
        foreach ($other->getClasses() as $id => $class) {
            if (!isset($this->classes[$id])) {
                $this->classes[$id] = $class;
            }
        }
        return $this;
    }

    /**
     * Filter results by IDs
     */
    public function filter(array $allowedIds): self
    {
        $filtered = array_intersect_key($this->results, array_flip($allowedIds));
        $classes = array_intersect_key($this->classes, $filtered);
        return new self($filtered, $this->query, count($filtered), $classes);
    }
}

<?php

namespace MSearch\Services\Indexer;

use MODX\Revolution\modX;
use MSearch\Adapters\ContentAdapterInterface;
use MSearch\Adapters\MsProductAdapter;
use MSearch\Adapters\ResourceAdapter;
use MSearch\Model\MseIntro;
use MSearch\Model\MseWord;
use MSearch\MSearch;

/**
 * Resource indexer service
 */
class Indexer implements IndexerInterface
{
    protected modX $modx;
    protected MSearch $msearch;

    /** @var ContentAdapterInterface[] */
    protected array $adapters = [];

    protected int $minWordLength;
    protected string $splitPattern;

    public function __construct(modX $modx, MSearch $msearch)
    {
        $this->modx = $modx;
        $this->msearch = $msearch;

        $this->minWordLength = (int) $modx->getOption('mse_index_min_word_length', null, 3);
        $this->splitPattern = $modx->getOption(
            'mse_index_split_words',
            null,
            '#\s|[,.:;!?"\'«»„"()\[\]{}<>]#u'
        );

        $this->registerDefaultAdapters();
    }

    /**
     * Register default content adapters
     */
    protected function registerDefaultAdapters(): void
    {
        $this->addAdapter(new ResourceAdapter($this->modx, $this->msearch));

        // Adapter for MiniShop3 — register only if msProduct class is loaded.
        // Same pattern is expected from third-party adapters: guard with class_exists.
        if (class_exists(\MiniShop3\Model\msProduct::class)) {
            $this->addAdapter(new MsProductAdapter($this->modx, $this->msearch));
        }

        // Allow third-party components to register their adapters
        $this->modx->invokeEvent('mseOnRegisterAdapters', [
            'indexer' => $this,
        ]);
    }

    /**
     * Add content adapter
     */
    public function addAdapter(ContentAdapterInterface $adapter): void
    {
        $this->adapters[] = $adapter;
        // Sort by priority
        usort($this->adapters, fn($a, $b) => $b->getPriority() <=> $a->getPriority());
    }

    /**
     * Get adapter for class.
     *
     * Returns the highest-priority adapter that supports the given class,
     * or null if no adapter matches.
     */
    public function getAdapter(string $className): ?ContentAdapterInterface
    {
        foreach ($this->adapters as $adapter) {
            if ($adapter->supports($className)) {
                return $adapter;
            }
        }
        return null;
    }

    /**
     * Get all registered adapters indexed by their type identifier.
     *
     * @return array<string, ContentAdapterInterface>
     */
    public function getAdaptersByType(): array
    {
        $result = [];
        foreach ($this->adapters as $adapter) {
            $result[$adapter->getType()] = $adapter;
        }
        return $result;
    }

    /**
     * Index a single resource
     */
    public function indexResource(int $resourceId): bool
    {
        try {
            $resource = $this->modx->getObject(\MODX\Revolution\modResource::class, $resourceId);
            if (!$resource) {
                $this->modx->log(modX::LOG_LEVEL_ERROR, "[mSearch] Resource not found: {$resourceId}");
                return false;
            }

            $className = $resource->get('class_key');
            $adapter = $this->getAdapter(get_class($resource));
            if (!$adapter) {
                $this->modx->log(modX::LOG_LEVEL_ERROR, "[mSearch] No adapter for class: {$className}");
                return false;
            }

            // Get fields and their weights
            $fields = $adapter->getIndexableFields();

            // Fire before event
            $this->modx->invokeEvent('mseOnBeforeIndex', [
                'resource' => $resource,
                'adapter' => $adapter,
            ]);

            // Remove existing index
            $this->removeResource($resourceId);

            // Fire event to modify fields
            $this->modx->invokeEvent('mseOnGetWorkFields', [
                'fields' => &$fields,
                'resource' => $resource,
            ]);

            $allWords = [];
            $introTexts = [];

            foreach ($fields as $field => $weight) {
                $content = $adapter->extractContent($resource, $field);
                if (empty($content)) {
                    continue;
                }

                $introTexts[] = $content;
                $words = $this->extractWords($content);

                foreach ($words as $word => $count) {
                    // Get base forms from morphology
                    $baseForms = $this->msearch->getMorphology()->getBaseForms($word);
                    if (empty($baseForms)) {
                        $baseForms = [$word];
                    }

                    foreach ($baseForms as $baseForm) {
                        if (!isset($allWords[$field][$baseForm])) {
                            $allWords[$field][$baseForm] = 0;
                        }
                        $allWords[$field][$baseForm] += $count;
                    }
                }
            }

            // Save words to index via batch INSERT IGNORE. Two benefits:
            //  - Race-safe: when two processes index the same resource at the
            //    same time (UI reindex + plugin-on-save, scheduler + plugin,
            //    etc.) the second INSERT silently no-ops on PK collision
            //    instead of throwing "Duplicate entry ... for key PRIMARY".
            //  - Much faster than N×xPDO::save(): one round-trip per chunk
            //    instead of one per word. On a typical content-rich resource
            //    that's 100-1000x fewer queries during a reindex.
            $this->saveWordsBatch($resourceId, $className, $allWords);

            // Save intro via INSERT IGNORE — same race-safety. Two parallel
            // processes write the same content (deterministic from resource),
            // so dropping the loser is correct.
            $this->saveIntroIgnore($resourceId, $className, implode(' ', $introTexts));

            // Fire after event
            $this->modx->invokeEvent('mseOnAfterIndex', [
                'resource' => $resource,
                'words' => $allWords,
                'adapter' => $adapter,
            ]);

            return true;
        } catch (\Throwable $e) {
            $this->modx->log(modX::LOG_LEVEL_ERROR, "[mSearch] indexResource exception for {$resourceId}: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
            return false;
        }
    }

    /**
     * Extract words from text
     */
    protected function extractWords(string $text): array
    {
        $text = mb_strtolower($text, 'UTF-8');
        $parts = preg_split($this->splitPattern, $text, -1, PREG_SPLIT_NO_EMPTY);

        $words = [];
        foreach ($parts as $word) {
            $word = trim($word);
            if (mb_strlen($word, 'UTF-8') < $this->minWordLength) {
                continue;
            }

            if (!isset($words[$word])) {
                $words[$word] = 0;
            }
            $words[$word]++;
        }

        return $words;
    }

    /**
     * Batch index resources across all registered adapters.
     *
     * Each adapter pulls its own subset (filtered by its supports() / class_key).
     * Pagination uses a unified offset that is applied to every adapter — one
     * tick indexes up to (limit × adapterCount) items.
     *
     * IDs already seen within this tick are skipped: when ResourceAdapter and a
     * specialized adapter (e.g. MsProductAdapter) both surface the same
     * resource, indexResource() is called only once.
     *
     * `total` returned to the UI is a single count across modx_site_content,
     * not the sum of per-adapter getTotal() — that sum would double-count
     * resources that match multiple adapters (a product hits ResourceAdapter
     * AND MsProductAdapter), inflating the progress bar's denominator and
     * the "Всего ресурсов" admin card.
     */
    public function indexBatch(array $options = []): array
    {
        $limit = $options['limit'] ?? 100;
        $offset = $options['offset'] ?? 0;

        if (empty($this->adapters)) {
            return ['indexed' => 0, 'offset' => 0, 'total' => 0, 'done' => true];
        }

        $criteria = [];
        if (!empty($options['class_key'])) {
            $criteria['class_key'] = $options['class_key'];
        }

        $indexed = 0;
        $seen = [];

        foreach ($this->adapters as $adapter) {
            foreach ($adapter->getObjects($criteria, $limit, $offset) as $resource) {
                $resourceId = (int) $resource->get('id');
                if (isset($seen[$resourceId])) {
                    continue;
                }
                $seen[$resourceId] = true;
                if ($this->indexResource($resourceId)) {
                    $indexed++;
                }
            }
        }

        $total = $this->getCachedIndexableTotal($criteria);
        $newOffset = $offset + $limit;

        return [
            'indexed' => $indexed,
            'offset' => $newOffset,
            'total' => $total,
            'done' => $newOffset >= $total,
        ];
    }

    /**
     * Batch save of accumulated words for one resource via INSERT IGNORE.
     *
     * Rows are chunked to keep individual statements under common limits
     * (max_allowed_packet, the 65535 parameter cap for prepared statements,
     * etc.). The chunk size is conservative and applies cleanly across
     * MySQL 5.7+ and MariaDB 10.3+.
     *
     * INSERT IGNORE drops rows that collide on the primary key
     * (resource, field, word, class_key) — that exact condition only arises
     * when a second indexing pass for the same resource races against the
     * first; both passes produce identical rows, so dropping the loser is
     * the correct semantics.
     *
     * @param array<string, array<string, int>> $words [field => [word => count]]
     */
    protected function saveWordsBatch(int $resourceId, string $className, array $words): void
    {
        $rows = [];
        foreach ($words as $field => $byWord) {
            foreach ($byWord as $word => $count) {
                $rows[] = [$resourceId, $field, $word, $count, $className];
            }
        }

        if (empty($rows)) {
            return;
        }

        $table = $this->modx->getTableName(MseWord::class);
        $chunkSize = 500;

        foreach (array_chunk($rows, $chunkSize) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '(?, ?, ?, ?, ?)'));
            $sql = "INSERT IGNORE INTO {$table} "
                . "(`resource`, `field`, `word`, `count`, `class_key`) "
                . "VALUES {$placeholders}";

            $params = [];
            foreach ($chunk as $row) {
                array_push($params, ...$row);
            }

            $stmt = $this->modx->prepare($sql);
            if (!$stmt || !$stmt->execute($params)) {
                $error = $stmt ? implode(' ', $stmt->errorInfo()) : 'prepare failed';
                $this->modx->log(
                    modX::LOG_LEVEL_ERROR,
                    "[mSearch] saveWordsBatch failed for resource={$resourceId}: {$error}"
                );
                return;
            }
        }
    }

    /**
     * Save the concatenated intro text for one resource via INSERT IGNORE.
     */
    protected function saveIntroIgnore(int $resourceId, string $className, string $intro): void
    {
        $table = $this->modx->getTableName(MseIntro::class);
        $sql = "INSERT IGNORE INTO {$table} "
            . "(`resource`, `intro`, `class_key`) "
            . "VALUES (?, ?, ?)";

        $stmt = $this->modx->prepare($sql);
        if (!$stmt || !$stmt->execute([$resourceId, $intro, $className])) {
            $error = $stmt ? implode(' ', $stmt->errorInfo()) : 'prepare failed';
            $this->modx->log(
                modX::LOG_LEVEL_ERROR,
                "[mSearch] saveIntroIgnore failed for resource={$resourceId}: {$error}"
            );
        }
    }

    /**
     * Count of indexable resources — one SQL over modx_site_content with the
     * filters every adapter uses (published, deleted, searchable). Centralised
     * here so we never sum per-adapter counts that would double-count items
     * matched by both ResourceAdapter (broad) and a specialised adapter like
     * MsProductAdapter (subset).
     */
    protected function countIndexable(array $criteria = []): int
    {
        $where = [
            'published' => true,
            'deleted' => false,
            'searchable' => true,
        ];
        if (!empty($criteria['class_key'])) {
            $where['class_key'] = $criteria['class_key'];
        }
        if (!empty($criteria['context_key'])) {
            $where['context_key'] = $criteria['context_key'];
        }

        return (int) $this->modx->getCount(\MODX\Revolution\modResource::class, $where);
    }

    /**
     * Cached version of countIndexable() for the AJAX-paginated reindex loop.
     * TTL 10 minutes — long enough to amortise across one reindex run,
     * short enough that admin doesn't see stale totals between sessions.
     */
    protected function getCachedIndexableTotal(array $criteria = []): int
    {
        $key = 'total/' . md5(serialize($criteria));
        $cached = $this->modx->cacheManager->get($key, ['cache_key' => 'msearch/indexer']);
        if (is_int($cached)) {
            return $cached;
        }

        $total = $this->countIndexable($criteria);
        $this->modx->cacheManager->set($key, $total, 600, ['cache_key' => 'msearch/indexer']);
        return $total;
    }

    /**
     * Remove resource from index
     */
    public function removeResource(int $resourceId): bool
    {
        // Remove words
        $this->modx->removeCollection(MseWord::class, ['resource' => $resourceId]);

        // Remove intro
        $this->modx->removeCollection(MseIntro::class, ['resource' => $resourceId]);

        return true;
    }

    /**
     * Clear entire index
     */
    public function clearIndex(): bool
    {
        $this->modx->exec("TRUNCATE TABLE {$this->modx->getTableName(MseWord::class)}");
        $this->modx->exec("TRUNCATE TABLE {$this->modx->getTableName(MseIntro::class)}");

        return true;
    }

    /**
     * Get index statistics — one count of indexable resources, plus the
     * actual mse_intro / mse_words row counts.
     */
    public function getStats(): array
    {
        $total = $this->countIndexable();

        $indexed = $this->modx->getCount(MseIntro::class);
        $words = $this->modx->getCount(MseWord::class);

        return [
            'total' => $total,
            'indexed' => $indexed,
            'words' => $words,
        ];
    }
}

<?php

namespace MSearch\Services\Indexer;

use MSearch\Adapters\ContentAdapterInterface;

/**
 * Indexer service interface
 */
interface IndexerInterface
{
    /**
     * Index a single resource
     */
    public function indexResource(int $resourceId): bool;

    /**
     * Batch index resources
     */
    public function indexBatch(array $options = []): array;

    /**
     * Remove resource from index
     */
    public function removeResource(int $resourceId): bool;

    /**
     * Clear entire index
     */
    public function clearIndex(): bool;

    /**
     * Get index statistics
     */
    public function getStats(): array;

    /**
     * Register a content adapter (called from mseOnRegisterAdapters event listeners).
     */
    public function addAdapter(ContentAdapterInterface $adapter): void;

    /**
     * Get the adapter that supports a given class name.
     */
    public function getAdapter(string $className): ?ContentAdapterInterface;

    /**
     * Get all registered adapters keyed by their type identifier.
     *
     * @return array<string, ContentAdapterInterface>
     */
    public function getAdaptersByType(): array;
}

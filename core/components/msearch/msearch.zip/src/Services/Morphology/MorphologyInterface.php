<?php

namespace MSearch\Services\Morphology;

/**
 * Morphology service interface
 */
interface MorphologyInterface
{
    /**
     * Get base forms of a word
     *
     * @param string $word Word to analyze
     * @return array Base forms
     */
    public function getBaseForms(string $word): array;

    /**
     * Get all forms of a word
     *
     * @param string $word Base word
     * @return array All word forms
     */
    public function getAllForms(string $word): array;

    /**
     * Check if dictionary is available for language
     *
     * @param string $language Language code (ru, en, de)
     * @return bool
     */
    public function hasDictionary(string $language): bool;

    /**
     * Get available dictionaries
     *
     * @return array List of available language codes
     */
    public function getAvailableDictionaries(): array;
}

<?php

namespace MSearch\Services\Morphology;

use MODX\Revolution\modX;
use MSearch\MSearch;
use phpMorphy;
use phpMorphy_FilesBundle;

/**
 * phpMorphy adapter for morphological analysis
 */
class PhpMorphyAdapter implements MorphologyInterface
{
    protected modX $modx;
    protected MSearch $msearch;

    /** @var phpMorphy[] */
    protected array $morphyInstances = [];

    protected array $availableLanguages = ['ru', 'en', 'de', 'uk'];
    protected string $defaultLanguage = 'ru';
    protected string $dictsPath;

    public function __construct(modX $modx, MSearch $msearch)
    {
        $this->modx = $modx;
        $this->msearch = $msearch;
        $this->dictsPath = $msearch->config['dictsPath'];
    }

    /**
     * Get phpMorphy instance for language
     */
    protected function getMorphy(string $language): ?phpMorphy
    {
        if (isset($this->morphyInstances[$language])) {
            return $this->morphyInstances[$language];
        }

        if (!$this->hasDictionary($language)) {
            return null;
        }

        try {
            $dictPath = $this->getDictPath($language);
            $locale = $this->getLocale($language);

            $this->morphyInstances[$language] = new phpMorphy(
                $dictPath,
                $locale,
                [
                    'storage' => 'file',
                    'predict_by_suffix' => true,
                    'predict_by_db' => true,
                ]
            );
        } catch (\Exception $e) {
            $this->modx->log(modX::LOG_LEVEL_ERROR, '[mSearch] phpMorphy error: ' . $e->getMessage());
            return null;
        }

        return $this->morphyInstances[$language];
    }

    /**
     * Get dictionary path for language
     */
    protected function getDictPath(string $language): string
    {
        return $this->dictsPath . $language . '/';
    }

    /**
     * Get locale for language
     */
    protected function getLocale(string $language): string
    {
        $locales = [
            'ru' => 'ru_RU',
            'en' => 'en_EN',
            'de' => 'de_DE',
            'uk' => 'uk_UA',
        ];

        return $locales[$language] ?? 'ru_RU';
    }

    /**
     * Detect language from word
     */
    protected function detectLanguage(string $word): string
    {
        // Ukrainian-specific letters: і ї є ґ
        if (preg_match('/[іїєґ]/iu', $word)) {
            return 'uk';
        }
        // Russian Cyrillic (excluding Ukrainian-specific)
        if (preg_match('/[а-яёъы]/iu', $word)) {
            return 'ru';
        }
        // German-specific letters
        if (preg_match('/[äöüß]/iu', $word)) {
            return 'de';
        }
        // Latin characters - English
        if (preg_match('/[a-z]/i', $word)) {
            return 'en';
        }

        // Default to Russian
        return 'ru';
    }

    /**
     * Get base forms of a word
     */
    public function getBaseForms(string $word): array
    {
        $word = mb_strtoupper(trim($word), 'UTF-8');
        if (empty($word)) {
            return [];
        }

        $language = $this->detectLanguage($word);
        $morphy = $this->getMorphy($language);

        if (!$morphy) {
            return [mb_strtolower($word, 'UTF-8')];
        }

        try {
            $forms = $morphy->getBaseForm($word);

            if ($forms === false || empty($forms)) {
                return [mb_strtolower($word, 'UTF-8')];
            }

            return array_map(fn($form) => mb_strtolower($form, 'UTF-8'), $forms);
        } catch (\Exception $e) {
            $this->modx->log(modX::LOG_LEVEL_WARN, '[mSearch] getBaseForms error: ' . $e->getMessage());
            return [mb_strtolower($word, 'UTF-8')];
        }
    }

    /**
     * Get all forms of a word
     */
    public function getAllForms(string $word): array
    {
        $word = mb_strtoupper(trim($word), 'UTF-8');
        if (empty($word)) {
            return [];
        }

        $language = $this->detectLanguage($word);
        $morphy = $this->getMorphy($language);

        if (!$morphy) {
            return [mb_strtolower($word, 'UTF-8')];
        }

        try {
            $forms = $morphy->getAllForms($word);

            if ($forms === false || empty($forms)) {
                return [mb_strtolower($word, 'UTF-8')];
            }

            return array_map(fn($form) => mb_strtolower($form, 'UTF-8'), $forms);
        } catch (\Exception $e) {
            $this->modx->log(modX::LOG_LEVEL_WARN, '[mSearch] getAllForms error: ' . $e->getMessage());
            return [mb_strtolower($word, 'UTF-8')];
        }
    }

    /**
     * Check if dictionary is available
     */
    public function hasDictionary(string $language): bool
    {
        $dictPath = $this->getDictPath($language);

        if (!is_dir($dictPath)) {
            return false;
        }

        // Check for required dictionary files (phpmorphy .bin format)
        $locale = strtolower($this->getLocale($language));
        $requiredFiles = [
            "morph_data.{$locale}.bin",
            "common_aut.{$locale}.bin",
        ];

        foreach ($requiredFiles as $file) {
            if (!file_exists($dictPath . $file)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get available dictionaries
     */
    public function getAvailableDictionaries(): array
    {
        $available = [];

        foreach ($this->availableLanguages as $language) {
            if ($this->hasDictionary($language)) {
                $available[] = $language;
            }
        }

        return $available;
    }
}

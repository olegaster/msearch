<?php

namespace MSearch\Services\Highlighter;

use MODX\Revolution\modX;
use MSearch\MSearch;

/**
 * Text highlighter service
 */
class Highlighter
{
    protected modX $modx;
    protected MSearch $msearch;

    protected string $tagOpen = '<mark class="mse-highlight">';
    protected string $tagClose = '</mark>';
    protected int $ellipsisLength = 200;
    protected string $ellipsis = '...';

    public function __construct(modX $modx, MSearch $msearch)
    {
        $this->modx = $modx;
        $this->msearch = $msearch;
    }

    /**
     * Highlight search terms in text.
     *
     * Returns HTML-safe output: input text is htmlspecialchars-escaped
     * before the highlight markup is injected. Callers can render the
     * result directly via innerHTML / unescaped chunk placeholders without
     * risk of script injection from raw resource fields (pagetitle, etc).
     */
    public function highlight(string $text, string $query, array $options = []): string
    {
        $this->applyOptions($options);

        if ($text === '') {
            return '';
        }

        // Escape FIRST — any matched span becomes <mark>escaped</mark>,
        // never <mark><script>...</script></mark>.
        $escaped = htmlspecialchars($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        if (empty($query)) {
            return $escaped;
        }

        $words = $this->getWordsToHighlight($query);
        if (empty($words)) {
            return $escaped;
        }

        $pattern = $this->buildPattern($words);

        return (string) preg_replace_callback(
            $pattern,
            fn($matches) => $this->tagOpen . $matches[0] . $this->tagClose,
            $escaped
        );
    }

    /**
     * Create excerpt with highlighted terms.
     *
     * Return value is HTML-safe (escaped). When there is no query to
     * highlight, the truncated text is still passed through highlight()
     * so the same escape pass applies.
     */
    public function excerpt(string $text, string $query, array $options = []): string
    {
        $this->applyOptions($options);

        if ($text === '') {
            return '';
        }
        if (empty($query)) {
            return $this->highlight($this->truncate($text), '', $options);
        }

        $words = $this->getWordsToHighlight($query);
        if (empty($words)) {
            return $this->truncate($text);
        }

        // Find first occurrence of any word
        $textLower = mb_strtolower($text, 'UTF-8');
        $firstPos = mb_strlen($text);

        foreach ($words as $word) {
            $pos = mb_strpos($textLower, mb_strtolower($word, 'UTF-8'));
            if ($pos !== false && $pos < $firstPos) {
                $firstPos = $pos;
            }
        }

        // Calculate excerpt boundaries
        $start = max(0, $firstPos - (int) ($this->ellipsisLength / 2));
        $length = $this->ellipsisLength;

        // Adjust to word boundaries
        if ($start > 0) {
            $spacePos = mb_strpos($text, ' ', $start);
            if ($spacePos !== false && $spacePos - $start < 20) {
                $start = $spacePos + 1;
            }
        }

        $excerpt = mb_substr($text, $start, $length, 'UTF-8');

        // Trim to word boundary at end
        if ($start + $length < mb_strlen($text)) {
            $lastSpace = mb_strrpos($excerpt, ' ');
            if ($lastSpace !== false && mb_strlen($excerpt) - $lastSpace < 20) {
                $excerpt = mb_substr($excerpt, 0, $lastSpace, 'UTF-8');
            }
        }

        // Add ellipsis
        if ($start > 0) {
            $excerpt = $this->ellipsis . $excerpt;
        }
        if ($start + $length < mb_strlen($text)) {
            $excerpt .= $this->ellipsis;
        }

        // Highlight
        return $this->highlight($excerpt, $query, $options);
    }

    /**
     * Get all word forms to highlight
     */
    protected function getWordsToHighlight(string $query): array
    {
        $splitPattern = $this->modx->getOption('mse_search_split_words', null, '#\s+#u');
        $queryWords = preg_split($splitPattern, mb_strtolower($query, 'UTF-8'), -1, PREG_SPLIT_NO_EMPTY);

        $allWords = [];

        foreach ($queryWords as $word) {
            // Add original word
            $allWords[] = $word;

            // Add all morphological forms
            $forms = $this->msearch->getMorphology()->getAllForms($word);
            $allWords = array_merge($allWords, $forms);
        }

        // Remove duplicates and empty strings
        return array_unique(array_filter($allWords));
    }

    /**
     * Build regex pattern for words.
     *
     * (*UCP) makes \w and \b Unicode-aware. Without it PCRE treats \b as an
     * ASCII word boundary ([A-Za-z0-9_]), so Cyrillic (and other non-Latin)
     * words highlight inconsistently — the boundary before "Смартфон" simply
     * isn't recognized. With (*UCP) the boundary respects \p{L}, so Cyrillic
     * is highlighted the same as Latin.
     */
    protected function buildPattern(array $words): string
    {
        $escaped = array_map(fn($word) => preg_quote($word, '/'), $words);

        // Sort by length descending to match longer words first
        usort($escaped, fn($a, $b) => mb_strlen($b) <=> mb_strlen($a));

        return '/(*UCP)\b(' . implode('|', $escaped) . ')\b/iu';
    }

    /**
     * Simple text truncation
     */
    protected function truncate(string $text): string
    {
        if (mb_strlen($text, 'UTF-8') <= $this->ellipsisLength) {
            return $text;
        }

        $excerpt = mb_substr($text, 0, $this->ellipsisLength, 'UTF-8');

        // Trim to word boundary
        $lastSpace = mb_strrpos($excerpt, ' ');
        if ($lastSpace !== false) {
            $excerpt = mb_substr($excerpt, 0, $lastSpace, 'UTF-8');
        }

        return $excerpt . $this->ellipsis;
    }

    /**
     * Apply options
     */
    protected function applyOptions(array $options): void
    {
        if (isset($options['tagOpen'])) {
            $this->tagOpen = $options['tagOpen'];
        }
        if (isset($options['tagClose'])) {
            $this->tagClose = $options['tagClose'];
        }
        if (isset($options['ellipsisLength'])) {
            $this->ellipsisLength = (int) $options['ellipsisLength'];
        }
        if (isset($options['ellipsis'])) {
            $this->ellipsis = $options['ellipsis'];
        }
    }
}

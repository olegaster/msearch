<?php

namespace MSearch\Adapters;

use MODX\Revolution\modSnippet;
use MODX\Revolution\modX;
use MSearch\MSearch;
use MSearch\Model\MseIntro;

/**
 * Abstract base adapter with common functionality
 */
abstract class AbstractAdapter implements ContentAdapterInterface
{
    protected modX $modx;
    protected MSearch $msearch;
    protected array $config;

    public function __construct(modX $modx, MSearch $msearch, array $config = [])
    {
        $this->modx = $modx;
        $this->msearch = $msearch;
        $this->config = $config;
    }

    /**
     * Get priority (default 0)
     */
    public function getPriority(): int
    {
        return 0;
    }

    /**
     * Default type — derive from class name (e.g. "ResourceAdapter" → "resource").
     * Concrete adapters should override with a stable identifier.
     */
    public function getType(): string
    {
        $parts = explode('\\', static::class);
        $name = end($parts);
        return strtolower(preg_replace('/Adapter$/', '', $name));
    }

    /**
     * Default: no display data. Adapters that want to participate in
     * suggest/search rendering should override this.
     */
    public function getDisplayData(array $ids, string $query = '', array $options = []): array
    {
        return [];
    }

    public function getDefaultSuggestTpl(): string
    {
        return 'mSearch.suggest.row';
    }

    public function getDefaultResultTpl(): string
    {
        return 'mSearch.row';
    }

    /**
     * Parse a comma-separated TV list into the placeholder names they occupy
     * in a pdoFetch/msProducts row: each name gets the given prefix.
     * Duplicates are collapsed (`color,color` → one entry).
     *
     * @return string[] e.g. ['color', 'size'] or ['tv_color', 'tv_size']
     */
    protected function parseTvFields(string $includeTVs, string $tvPrefix = ''): array
    {
        $fields = [];
        foreach (explode(',', $includeTVs) as $tv) {
            $tv = trim($tv);
            if ($tv !== '') {
                $fields[] = $tvPrefix . $tv;
            }
        }
        return array_values(array_unique($fields));
    }

    /**
     * Decide which TV placeholders are safe to highlight — called ONCE per
     * request (before the per-row loop), so its logging never floods.
     *
     * Excluded:
     *  - computed placeholders (id, url, intro, price_display, image, ...) —
     *    a TV named like one of these would clobber the adapter's own value;
     *    logged once so the misconfiguration is visible.
     *  - TVs sent through processTVs/prepareTVs — their value is rendered
     *    output (a URL, HTML, an output-filter result), not the searched text,
     *    so highlighting it would corrupt it (e.g. <mark> inside an image URL).
     *
     * @param string[] $tvFields  Candidate placeholder names (prefixed)
     * @param string[] $extraReserved  Adapter-specific computed keys, added to the common base
     * @param string $processTVs  Raw processTVs value ('a,b', or '1' meaning every TV)
     * @param string $prepareTVs  Raw prepareTVs value
     * @param string $tvPrefix
     * @return string[]
     */
    protected function highlightableTvFields(
        array $tvFields,
        array $extraReserved = [],
        string $processTVs = '',
        string $prepareTVs = '',
        string $tvPrefix = ''
    ): array {
        // Base set of computed placeholders every adapter produces — a TV whose
        // name matches one of these would clobber the adapter's own value.
        $reserved = array_merge([
            'id', 'url', 'type', 'class_key', 'context_key', 'idx', 'query',
            'pagetitle', 'pagetitle_raw', 'longtitle', 'longtitle_raw',
            'description', 'description_raw', 'introtext', 'intro',
        ], $extraReserved);

        // processTVs=1 means pdoFetch renders EVERY TV (renderOutput). pdoFetch
        // compares config['processTVs'] == 1, so only the literal '1' triggers
        // it — we don't accept 'all' (it would look up a TV literally named
        // "all" and silently render nothing). prepareTVs is NOT treated as
        // render-all: its =1 form only touches image/file TVs (sourceCache),
        // leaving text TVs highlightable — those are excluded field-by-field.
        if ($processTVs === '1') {
            return [];
        }

        $rendered = array_merge(
            $this->parseTvFields($processTVs, $tvPrefix),
            $this->parseTvFields($prepareTVs, $tvPrefix)
        );

        $safe = [];
        foreach ($tvFields as $field) {
            if (in_array($field, $reserved, true)) {
                $this->modx->log(
                    modX::LOG_LEVEL_ERROR,
                    "[mSearch] TV placeholder '{$field}' collides with a computed field — not highlighted. Use tvPrefix to avoid the clash."
                );
                continue;
            }
            if (in_array($field, $rendered, true)) {
                // rendered output (URL/HTML) — display it, don't highlight
                continue;
            }
            $safe[] = $field;
        }
        return $safe;
    }

    /**
     * Per-row highlight of the (already-vetted) TV placeholders. For each
     * `field` sets `field` (highlighted) and `field_raw` (original).
     *
     * Per-row guards only (reserved/rendered filtering happens once in
     * highlightableTvFields):
     *  - placeholder missing from the row (typo / TV not loaded) → skipped,
     *    not materialised as an empty string.
     *  - non-scalar value (MIGX / JSON TV decoded to an array) → skipped;
     *    `(string) $array` would emit "Array" plus a warning.
     *
     * @param array<string,mixed> $data Target placeholder set (modified copy returned)
     * @param array<string,mixed> $row  Source row with raw TV values
     * @param string[] $tvFields Vetted placeholder names to highlight
     * @return array<string,mixed>
     */
    protected function highlightTvFields(array $data, array $row, array $tvFields, string $query): array
    {
        foreach ($tvFields as $field) {
            if (!array_key_exists($field, $row)) {
                continue;
            }
            $value = $row[$field];
            if (!is_scalar($value)) {
                continue;
            }
            $raw = (string) $value;
            $data[$field . '_raw'] = $raw;
            $data[$field] = $this->highlight($raw, $query);
        }
        return $data;
    }

    /**
     * Run an external snippet to load row data for the given IDs.
     *
     * The snippet receives caller-supplied `$extraProps` plus two reserved
     * keys that the adapter always controls:
     *  - `resources` — comma-separated IDs from the Searcher (mSearch order)
     *  - `return`    — fixed to `json`, so we get a JSON-encoded array back
     *
     * If the snippet does not exist or returns unparseable output, this
     * method logs and returns an empty array — the adapter can decide what
     * to do (typically: skip enrichment, return empty for those IDs).
     *
     * SECURITY: `$element` is a snippet name that will be executed. The
     * caller is responsible for ensuring it comes from a trusted source
     * (snippet properties / system settings / event listeners). Never pass
     * a value originating from the client — runSnippet() can execute
     * arbitrary PHP via custom snippets and is effectively RCE if abused.
     *
     * @param int[] $ids
     * @param array<string,mixed> $extraProps
     * @return array<int, array<string,mixed>> rows keyed by id
     */
    protected function loadViaElement(string $element, array $ids, array $extraProps = []): array
    {
        if ($element === '' || empty($ids)) {
            return [];
        }

        if (!$this->modx->getObject(modSnippet::class, ['name' => $element])) {
            $this->modx->log(
                modX::LOG_LEVEL_ERROR,
                "[mSearch] element snippet not found: {$element}"
            );
            return [];
        }

        $props = array_merge($extraProps, [
            'resources' => implode(',', array_map('intval', $ids)),
            'return' => 'json',
        ]);

        $output = $this->modx->runSnippet($element, $props);
        if (!is_string($output) || $output === '') {
            return [];
        }

        $decoded = json_decode($output, true);
        if (!is_array($decoded)) {
            $this->modx->log(
                modX::LOG_LEVEL_ERROR,
                "[mSearch] element snippet '{$element}' did not return valid JSON array"
            );
            return [];
        }

        // Index by id for fast lookup during enrichment
        $rows = [];
        foreach ($decoded as $row) {
            if (!is_array($row) || !isset($row['id'])) {
                continue;
            }
            $rows[(int) $row['id']] = $row;
        }

        return $rows;
    }

    /**
     * Batch-load intro texts from mse_intro for the given resource IDs.
     *
     * Shared by all adapters that need to expose intros as placeholders —
     * raw PDO to avoid hydrating xPDO objects.
     *
     * @param int[] $ids
     * @return array<int, string>
     */
    protected function loadIntros(array $ids): array
    {
        if (empty($ids)) {
            return [];
        }

        $introTable = $this->modx->getTableName(MseIntro::class);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = "SELECT `resource`, `intro` FROM {$introTable} WHERE `resource` IN ({$placeholders})";

        $intros = [];
        $stmt = $this->modx->prepare($sql);
        if ($stmt && $stmt->execute(array_values($ids))) {
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $intros[(int) $row['resource']] = $row['intro'];
            }
            $stmt->closeCursor();
        }

        return $intros;
    }

    /**
     * Apply server-side highlight via MSearch facade.
     *
     * The Highlighter service always returns HTML-escaped output, so it is
     * safe to render the result directly in chunks (no extra |escape filter
     * required) and the controller can return it inside an `html` field
     * that the frontend will innerHTML.
     */
    protected function highlight(string $text, string $query, array $options = []): string
    {
        return $this->msearch->highlight($text, $query, $options);
    }

    /**
     * Extract a TV value as searchable plain text.
     *
     * Handles two common shapes:
     *  - scalar value → cleaned through cleanText()
     *  - JSON array (MIGX and similar) → flattened to a space-separated string
     *
     * Works with any object that exposes getTVValue() — typically modResource
     * and its subclasses.
     */
    protected function extractTvContent(object $object, string $tvName): string
    {
        if (!method_exists($object, 'getTVValue')) {
            return '';
        }

        $value = $object->getTVValue($tvName);
        if (empty($value)) {
            return '';
        }

        if (is_string($value) && str_starts_with($value, '[')) {
            $decoded = json_decode($value, true);
            if (is_array($decoded)) {
                $value = $this->flattenArray($decoded);
            }
        }

        return $this->cleanText((string) $value);
    }

    /**
     * Flatten a nested array into a space-separated string of its string
     * leaves. Numbers are skipped — TV-stored numeric IDs aren't useful for
     * full-text indexing.
     */
    protected function flattenArray(array $array): string
    {
        $result = [];
        array_walk_recursive($array, function ($value) use (&$result) {
            if (is_string($value) && !empty($value) && !is_numeric($value)) {
                $result[] = $value;
            }
        });
        return implode(' ', $result);
    }

    /**
     * Strip HTML and normalize whitespace
     */
    protected function cleanText(string $text): string
    {
        // Remove HTML tags
        $text = strip_tags($text);

        // Decode HTML entities
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Normalize whitespace
        $text = preg_replace('/\s+/u', ' ', $text);

        return trim($text);
    }

    /**
     * Parse field weights from setting string
     *
     * @param string $fields Format: "field1:3,field2:1,field3:2"
     * @return array [field => weight]
     */
    protected function parseFieldWeights(string $fields): array
    {
        $result = [];

        $parts = explode(',', $fields);
        foreach ($parts as $part) {
            $part = trim($part);
            if (empty($part)) {
                continue;
            }

            if (str_contains($part, ':')) {
                [$field, $weight] = explode(':', $part, 2);
                $result[trim($field)] = (int) $weight;
            } else {
                $result[$part] = 1;
            }
        }

        return $result;
    }
}

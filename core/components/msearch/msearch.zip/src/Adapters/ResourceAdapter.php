<?php

namespace MSearch\Adapters;

use ModxPro\PdoTools\Fetch;
use MODX\Revolution\modResource;
use MODX\Revolution\modX;

/**
 * Adapter for modResource indexing and rendering
 */
class ResourceAdapter extends AbstractAdapter
{
    protected array $tvCache = [];

    /**
     * Stable type identifier used in chunk lookups (tplSuggestResource etc.)
     */
    public function getType(): string
    {
        return 'resource';
    }

    /**
     * Supports modResource and its descendants.
     * Has lower priority than concrete adapters (e.g. MsProductAdapter)
     * so that subclassed resources fall through to their own adapter first.
     */
    public function supports(string $className): bool
    {
        return $className === modResource::class
            || is_subclass_of($className, modResource::class);
    }

    /**
     * Get indexable fields from settings
     */
    public function getIndexableFields(): array
    {
        $fields = $this->modx->getOption(
            'mse_index_fields',
            null,
            'pagetitle:3,longtitle:2,description:2,introtext:2,content:1'
        );

        return $this->parseFieldWeights($fields);
    }

    /**
     * Extract content from resource field
     */
    public function extractContent(object $object, string $field): string
    {
        if (!$object instanceof modResource) {
            return '';
        }

        // Check if it's a TV
        if (str_starts_with($field, 'tv_') || str_starts_with($field, 'tv.')) {
            $tvName = preg_replace('/^tv[._]/', '', $field);
            return $this->extractTvContent($object, $tvName);
        }

        // Regular resource field
        $value = $object->get($field);

        if ($value === null) {
            return '';
        }

        return $this->cleanText((string) $value);
    }

    /**
     * Get resources for indexing.
     *
     * By default returns ALL resource subclasses (modResource, modDocument,
     * msProduct, msCategory, ...). Indexer::indexResource() will route each
     * item to its specialized adapter by class_key if one exists. The double
     * iteration over msProduct (here and in MsProductAdapter::getObjects)
     * is intentional and safe — indexResource() removes prior index entries
     * before re-inserting, so the result is identical regardless of route.
     */
    public function getObjects(array $criteria, int $limit, int $offset): iterable
    {
        $c = $this->modx->newQuery(modResource::class);

        $where = [
            'published' => true,
            'deleted' => false,
            'searchable' => true,
        ];
        if (!empty($criteria['class_key'])) {
            $where['class_key'] = $criteria['class_key'];
        }
        $c->where($where);

        if (!empty($criteria['context_key'])) {
            $c->where(['context_key' => $criteria['context_key']]);
        }
        if (!empty($criteria['parent'])) {
            $c->where(['parent' => $criteria['parent']]);
        }

        $c->sortby('id', 'ASC');
        $c->limit($limit, $offset);

        return $this->modx->getIterator(modResource::class, $c);
    }

    /**
     * Get total count of indexable resources (all subclasses unless a
     * specific class_key is provided in criteria).
     */
    public function getTotal(array $criteria = []): int
    {
        $c = $this->modx->newQuery(modResource::class);

        $where = [
            'published' => true,
            'deleted' => false,
            'searchable' => true,
        ];
        if (!empty($criteria['class_key'])) {
            $where['class_key'] = $criteria['class_key'];
        }
        $c->where($where);

        if (!empty($criteria['context_key'])) {
            $c->where(['context_key' => $criteria['context_key']]);
        }

        return $this->modx->getCount(modResource::class, $c);
    }

    /**
     * Batch-load resource rows + intros for rendering.
     *
     * Data is loaded through pdoFetch (return=data — raw rows, no xPDO object
     * hydration), which also gives us pdoTools' native TV support: pass
     * `includeTVs` / `tvPrefix` via snippet properties and the requested TVs
     * appear as placeholders in the suggestion chunk. Text TVs from the
     * includeTVs list are highlighted just like pagetitle/intro.
     *
     * `$options['element']` is intentionally ignored — ResourceAdapter has no
     * dedicated snippet integration; TVs cover the common "extra field" need.
     */
    public function getDisplayData(array $ids, string $query = '', array $options = []): array
    {
        if (empty($ids)) {
            return [];
        }

        $includeTVs = trim((string) ($options['includeTVs'] ?? ''));
        $tvPrefix   = (string) ($options['tvPrefix'] ?? '');
        // processTVs/prepareTVs let image/file TVs come back rendered (with
        // media-source baseUrl) or run their output filters. Off by default —
        // raw values are faster for plain text TVs.
        $processTVs = trim((string) ($options['processTVs'] ?? ''));
        $prepareTVs = trim((string) ($options['prepareTVs'] ?? ''));

        // Explicit column list — NOT an empty select. Empty select makes
        // pdoFetch fetch every column including the (potentially huge) content
        // body on each keystroke. tvsSelect is merged into any explicit select
        // by addSelects(), so TVs are unaffected.
        // NOTE: `id` must stay in this list — processTVs calls
        // renderOutput($row['id']); dropping id would silently break it.
        $select = 'id,pagetitle,longtitle,description,introtext,uri,'
            . 'context_key,publishedon,createdon,editedon,published,deleted';

        /** @var Fetch $pdoFetch */
        $pdoFetch = $this->modx->services->get(Fetch::class);
        $pdoFetch->setConfig([
            'class'      => modResource::class,
            'resources'  => implode(',', array_map('intval', $ids)),
            'return'     => 'data',
            'select'     => $select,
            'includeTVs' => $includeTVs,
            'tvPrefix'   => $tvPrefix,
            'processTVs' => $processTVs,
            'prepareTVs' => $prepareTVs,
            'sortby'     => '',   // order restored manually from $ids below
            'limit'      => 0,
            'where'      => ['published' => true, 'deleted' => false],
        ], true);

        $rows = $pdoFetch->run();

        if (!is_array($rows)) {
            // pdoFetch returned a non-array (error path). $ids was non-empty,
            // so an empty result here is unexpected — log it.
            $this->modx->log(
                modX::LOG_LEVEL_ERROR,
                '[mSearch] ResourceAdapter pdoFetch returned non-array for ids: '
                . implode(',', array_slice(array_map('intval', $ids), 0, 20))
            );
            return [];
        }

        // Index rows by id
        $byId = [];
        foreach ($rows as $row) {
            if (isset($row['id'])) {
                $byId[(int) $row['id']] = $row;
            }
        }

        if (empty($byId)) {
            return [];
        }

        $intros = $this->loadIntros(array_keys($byId));

        // Which TVs to highlight — decided ONCE (excludes computed placeholders
        // and processTVs/prepareTVs rendered output; logs collisions once).
        $tvFields = $this->highlightableTvFields(
            $this->parseTvFields($includeTVs, $tvPrefix),
            ['uri'],   // extra reserved beyond the common set — uri is used in chunks
            $processTVs,
            $prepareTVs,
            $tvPrefix
        );

        $result = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if (!isset($byId[$id])) {
                continue;
            }
            $row = $byId[$id];

            $contextKey = $row['context_key'] ?? 'web';
            $url = $this->modx->makeUrl($id, $contextKey, '', 'full');
            $introText = $intros[$id] ?? $row['introtext'] ?? '';

            $pagetitle   = (string) ($row['pagetitle'] ?? '');
            $longtitle   = (string) ($row['longtitle'] ?? '');
            $description = (string) ($row['description'] ?? '');

            // Keep all raw pdoFetch fields (incl. TVs), then override display ones
            $data = array_merge($row, [
                'id'              => $id,
                'class_key'       => modResource::class,
                'type'            => $this->getType(),
                'url'             => $url,
                'context_key'     => $contextKey,
                'pagetitle'       => $this->highlight($pagetitle, $query),
                'pagetitle_raw'   => $pagetitle,
                'longtitle'       => $this->highlight($longtitle, $query),
                'longtitle_raw'   => $longtitle,
                'description'     => $this->highlight($description, $query),
                'description_raw' => $description,
                'intro'           => $this->highlight($introText, $query, ['ellipsisLength' => 100]),
            ]);

            // Highlight requested TVs, keep raw versions
            $data = $this->highlightTvFields($data, $row, $tvFields, $query);

            $result[$id] = $data;
        }

        return $result;
    }

    public function getDefaultSuggestTpl(): string
    {
        return 'mSearch.suggest.row';
    }

    public function getDefaultResultTpl(): string
    {
        return 'mSearch.row';
    }
}

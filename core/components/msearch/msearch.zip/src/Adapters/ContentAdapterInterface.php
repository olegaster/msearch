<?php

namespace MSearch\Adapters;

/**
 * Content adapter interface for indexing and displaying different object types
 */
interface ContentAdapterInterface
{
    /**
     * Check if adapter supports given class
     *
     * @param string $className Object class name
     * @return bool
     */
    public function supports(string $className): bool;

    /**
     * Short type identifier used as a placeholder key (e.g. "resource", "product")
     *
     * Used to map snippet properties (tplSuggest{Type}) onto adapters.
     */
    public function getType(): string;

    /**
     * Get fields available for indexing with their weights
     *
     * @return array [field_name => weight]
     */
    public function getIndexableFields(): array;

    /**
     * Extract content from object field
     *
     * @param object $object Object to extract from
     * @param string $field Field name
     * @return string Extracted text content
     */
    public function extractContent(object $object, string $field): string;

    /**
     * Get objects for indexing
     *
     * @param array $criteria Filter criteria
     * @param int $limit Limit
     * @param int $offset Offset
     * @return iterable Objects to index
     */
    public function getObjects(array $criteria, int $limit, int $offset): iterable;

    /**
     * Get total count of objects
     *
     * @param array $criteria Filter criteria
     * @return int
     */
    public function getTotal(array $criteria = []): int;

    /**
     * Get adapter priority (higher = processed first)
     *
     * @return int
     */
    public function getPriority(): int;

    /**
     * Batch-load placeholder data for the given IDs.
     *
     * Returns map [id => array_of_placeholders] where placeholders are passed
     * directly into the chunk renderer. Adapter is responsible for highlighting
     * relevant fields if $query is non-empty.
     *
     * $options carries snippet-level configuration that the controller pulls
     * from the session — typically `element` (name of an external snippet to
     * load rows from) and `elementProperties` (extra parameters for that
     * snippet). An adapter is free to honor or ignore these.
     *
     * @param int[] $ids
     * @param string $query Optional query string for server-side highlighting
     * @param array<string,mixed> $options Snippet-level options (element, elementProperties, ...)
     * @return array<int, array<string, mixed>>
     */
    public function getDisplayData(array $ids, string $query = '', array $options = []): array;

    /**
     * Default chunk name for autocomplete suggestions
     */
    public function getDefaultSuggestTpl(): string;

    /**
     * Default chunk name for full search result rows
     */
    public function getDefaultResultTpl(): string;
}

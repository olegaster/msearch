<?php

namespace MSearch\Adapters;

use MiniShop3\Model\msProduct;
use MiniShop3\Model\msProductData;
use MODX\Revolution\modResource;

/**
 * Adapter for MiniShop3 msProduct.
 *
 * Indexes both modResource fields (inherited via class_key) and
 * msProductData fields (article). Renders suggestions/results with
 * price, thumb and old_price loaded from ms3_products.
 *
 * Registered in Indexer only when MiniShop3\Model\msProduct exists.
 */
class MsProductAdapter extends AbstractAdapter
{
    public function getType(): string
    {
        return 'product';
    }

    /**
     * Higher priority than ResourceAdapter so msProduct objects are
     * routed here, not to the generic resource adapter.
     */
    public function getPriority(): int
    {
        return 10;
    }

    public function supports(string $className): bool
    {
        if (!class_exists(msProduct::class)) {
            return false;
        }
        return $className === msProduct::class
            || is_subclass_of($className, msProduct::class);
    }

    /**
     * Index both modResource fields and product-specific fields like article.
     */
    public function getIndexableFields(): array
    {
        $fields = $this->modx->getOption(
            'mse_index_fields_product',
            null,
            'pagetitle:3,longtitle:2,description:2,introtext:2,article:3'
        );

        return $this->parseFieldWeights($fields);
    }

    /**
     * Extract content via msProduct's overridden get() — it transparently
     * resolves both modResource and msProductData fields.
     */
    public function extractContent(object $object, string $field): string
    {
        if (!$object instanceof msProduct) {
            return '';
        }

        if (str_starts_with($field, 'tv_') || str_starts_with($field, 'tv.')) {
            $tvName = preg_replace('/^tv[._]/', '', $field);
            return $this->extractTvContent($object, $tvName);
        }

        $value = $object->get($field);
        if ($value === null || is_array($value)) {
            return '';
        }

        return $this->cleanText((string) $value);
    }

    public function getObjects(array $criteria, int $limit, int $offset): iterable
    {
        $c = $this->modx->newQuery(msProduct::class);
        $c->where([
            'class_key' => msProduct::class,
            'published' => true,
            'deleted' => false,
            'searchable' => true,
        ]);

        if (!empty($criteria['context_key'])) {
            $c->where(['context_key' => $criteria['context_key']]);
        }
        if (!empty($criteria['parent'])) {
            $c->where(['parent' => $criteria['parent']]);
        }

        $c->sortby('id', 'ASC');
        $c->limit($limit, $offset);

        return $this->modx->getIterator(msProduct::class, $c);
    }

    public function getTotal(array $criteria = []): int
    {
        $c = $this->modx->newQuery(msProduct::class);
        $c->where([
            'class_key' => msProduct::class,
            'published' => true,
            'deleted' => false,
            'searchable' => true,
        ]);

        if (!empty($criteria['context_key'])) {
            $c->where(['context_key' => $criteria['context_key']]);
        }

        return $this->modx->getCount(msProduct::class, $c);
    }

    /**
     * Batch-load product rows + enrich for chunk rendering.
     *
     * When `$options['element']` is provided, the data is sourced from that
     * external snippet (e.g. `msProducts`) — so discount plugins, currency
     * formatting, and miniShop3 events (msOnProductsLoad, msOnProductPrepare,
     * msOnGetProductPrice) are honored. Otherwise we fall back to a fast raw
     * SQL JOIN over modx_site_content × ms3_products.
     *
     * Caller-supplied `elementProperties` are forwarded to the snippet, except
     * for the two reserved keys (`resources`, `return`) which AbstractAdapter
     * always overrides.
     */
    public function getDisplayData(array $ids, string $query = '', array $options = []): array
    {
        if (empty($ids) || !class_exists(msProduct::class)) {
            return [];
        }

        $element = (string) ($options['element'] ?? '');
        $elementProps = is_array($options['elementProperties'] ?? null)
            ? $options['elementProperties']
            : [];

        // Unified &includeTVs: the same top-level snippet property that works
        // for ResourceAdapter also works here. When loading products through
        // an external snippet (e.g. the msProducts snippet — a pdoFetch
        // wrapper) we merge the TV request into its properties so the snippet
        // joins the TVs — the user never has to know it goes into
        // elementProperties.
        $topIncludeTVs = trim((string) ($options['includeTVs'] ?? ''));
        $processTVs    = trim((string) ($options['processTVs'] ?? ''));
        $prepareTVs    = trim((string) ($options['prepareTVs'] ?? ''));

        // Effective TV settings: values set explicitly in elementProperties win
        // over the top-level &includeTVs/&processTVs/&prepareTVs. Everything
        // downstream — merging into the snippet call and deciding what to
        // highlight — keys off the effective values, so a processTVs passed
        // only through elementProperties still excludes that TV from highlight.
        $effectiveTVs = trim((string) ($elementProps['includeTVs'] ?? ''));
        if ($effectiveTVs === '') {
            $effectiveTVs = $topIncludeTVs;
        }
        $effectivePrefix  = (string) ($elementProps['tvPrefix'] ?? ($options['tvPrefix'] ?? ''));
        $effectiveProcess = (string) ($elementProps['processTVs'] ?? $processTVs);
        $effectivePrepare = (string) ($elementProps['prepareTVs'] ?? $prepareTVs);

        if ($effectiveTVs !== '') {
            if (!isset($elementProps['includeTVs']) || $elementProps['includeTVs'] === '') {
                $elementProps['includeTVs'] = $effectiveTVs;
            }
            if (!isset($elementProps['tvPrefix'])) {
                $elementProps['tvPrefix'] = $effectivePrefix;
            }
            if ($effectiveProcess !== '' && !isset($elementProps['processTVs'])) {
                $elementProps['processTVs'] = $effectiveProcess;
            }
            if ($effectivePrepare !== '' && !isset($elementProps['prepareTVs'])) {
                $elementProps['prepareTVs'] = $effectivePrepare;
            }
        }

        $rows = $element !== ''
            ? $this->loadViaElement($element, $ids, $elementProps)
            : $this->loadNatively($ids);

        if (empty($rows)) {
            return [];
        }

        return $this->enrich($rows, $ids, $query, $effectiveTVs, $effectivePrefix, $effectiveProcess, $effectivePrepare);
    }

    /**
     * Fast path: raw JOIN modx_site_content × ms3_products. No discount
     * plugins, no formatting — just the underlying columns.
     *
     * @param int[] $ids
     * @return array<int, array<string,mixed>>
     */
    protected function loadNatively(array $ids): array
    {
        $resourceTable = $this->modx->getTableName(modResource::class);
        $dataTable = $this->modx->getTableName(msProductData::class);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        // class_key filter guards against accidentally grouping a non-product
        // id under MsProductAdapter (e.g. orphaned mse_intro row).
        $sql = "SELECT
                    r.`id`, r.`pagetitle`, r.`longtitle`, r.`description`, r.`introtext`,
                    r.`uri`, r.`context_key`, r.`publishedon`, r.`createdon`, r.`editedon`,
                    d.`article`, d.`price`, d.`old_price`, d.`weight`,
                    d.`image`, d.`thumb`, d.`vendor_id`, d.`made_in`,
                    d.`new`, d.`popular`, d.`favorite`
                FROM {$resourceTable} r
                LEFT JOIN {$dataTable} d ON d.`id` = r.`id`
                WHERE r.`id` IN ({$placeholders})
                  AND r.`class_key` = ?
                  AND r.`published` = 1
                  AND r.`deleted` = 0";

        $params = array_values($ids);
        $params[] = msProduct::class;

        $rows = [];
        $stmt = $this->modx->prepare($sql);
        if ($stmt && $stmt->execute($params)) {
            while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
                $rows[(int) $row['id']] = $row;
            }
            $stmt->closeCursor();
        }

        return $rows;
    }

    /**
     * Common post-processing: add highlighted fields, url, type, intro,
     * discount flag — placeholders that the suggestion chunk consumes.
     *
     * `$rows` may come from native SQL or from an external snippet (where
     * fields like `price` may already be string-formatted). We don't
     * re-process numeric fields here — whatever the source provided wins.
     *
     * @param array<int, array<string,mixed>> $rows
     * @param int[] $orderedIds Order to follow when assembling the result
     * @return array<int, array<string,mixed>>
     */
    protected function enrich(array $rows, array $orderedIds, string $query, string $includeTVs = '', string $tvPrefix = '', string $processTVs = '', string $prepareTVs = ''): array
    {
        $intros = $this->loadIntros(array_keys($rows));

        // Which TVs to highlight — decided ONCE (excludes product-computed
        // placeholders and processTVs/prepareTVs rendered output; logs once).
        $tvFields = $this->highlightableTvFields(
            $this->parseTvFields($includeTVs, $tvPrefix),
            [
                'article', 'article_raw', 'price', 'old_price',
                'price_display', 'old_price_display', 'has_discount',
                'thumb', 'image',
            ],
            $processTVs,
            $prepareTVs,
            $tvPrefix
        );

        $result = [];
        foreach ($orderedIds as $id) {
            $id = (int) $id;
            if (!isset($rows[$id])) {
                continue;
            }
            $row = $rows[$id];

            $contextKey = $row['context_key'] ?? 'web';
            $url = $this->modx->makeUrl($id, $contextKey, '', 'full');
            $introText = $intros[$id] ?? $row['introtext'] ?? '';

            $pagetitle = (string) ($row['pagetitle'] ?? '');
            $longtitle = (string) ($row['longtitle'] ?? '');
            $description = (string) ($row['description'] ?? '');
            $article = (string) ($row['article'] ?? '');

            $price = $row['price'] ?? 0;
            $oldPrice = $row['old_price'] ?? 0;

            // Compose the user-facing display string. Three sources compete,
            // in this order of preference:
            //
            //  1) `price_formatted` (miniShop3 >= PR #269) — already formatted
            //     with currency symbol and locale-specific separators when
            //     msProducts ran with formatPrices=1. Best choice when present.
            //
            //  2) Numeric `price` — own number_format() pass. Covers the
            //     native SQL path and old miniShop3 with formatPrices=0.
            //
            //  3) Anything else — cast to string verbatim. Covers legacy
            //     miniShop3 (< PR #269) with formatPrices=1, where price was
            //     returned as an already-formatted string.
            $priceFormatted = $row['price_formatted'] ?? '';
            if (is_string($priceFormatted) && $priceFormatted !== '') {
                $priceDisplay = $priceFormatted;
            } elseif (is_numeric($price)) {
                $priceDisplay = number_format((float) $price, 2, '.', ' ');
            } else {
                $priceDisplay = (string) $price;
            }

            $oldPriceFormatted = $row['old_price_formatted'] ?? '';
            if (is_string($oldPriceFormatted) && $oldPriceFormatted !== '') {
                $oldPriceDisplay = $oldPriceFormatted;
            } elseif (is_numeric($oldPrice)) {
                $oldPriceDisplay = number_format((float) $oldPrice, 2, '.', ' ');
            } else {
                $oldPriceDisplay = (string) $oldPrice;
            }

            // has_discount: prefer ms3_products' `discount` field (always
            // numeric, computed before formatPrices). Fall back to numeric
            // comparison for native-flow.
            if (isset($row['discount']) && is_numeric($row['discount'])) {
                $hasDiscount = (float) $row['discount'] > 0;
            } else {
                $hasDiscount = is_numeric($price) && is_numeric($oldPrice)
                    && (float) $oldPrice > 0 && (float) $oldPrice > (float) $price;
            }

            $result[$id] = array_merge($row, [
                'id' => $id,
                'class_key' => msProduct::class,
                'type' => $this->getType(),
                'url' => $url,
                'context_key' => $contextKey,

                'pagetitle' => $this->highlight($pagetitle, $query),
                'pagetitle_raw' => $pagetitle,
                'longtitle' => $this->highlight($longtitle, $query),
                'longtitle_raw' => $longtitle,
                'description' => $this->highlight($description, $query),
                'description_raw' => $description,
                'intro' => $this->highlight($introText, $query, ['ellipsisLength' => 100]),

                'article' => $this->highlight($article, $query),
                'article_raw' => $article,
                'price_display' => $priceDisplay,
                'old_price_display' => $oldPriceDisplay,
                'has_discount' => $hasDiscount,
            ]);

            // Highlight the already-vetted TVs (same helper as ResourceAdapter)
            $result[$id] = $this->highlightTvFields($result[$id], $row, $tvFields, $query);
        }

        return $result;
    }

    public function getDefaultSuggestTpl(): string
    {
        return 'mSearch.suggest.row';
    }

    public function getDefaultResultTpl(): string
    {
        return 'mSearch.row';
    }
}

<?php

namespace MSearch\Controllers\Api;

use ModxPro\PdoTools\Fetch;
use MODX\Revolution\modChunk;
use MODX\Revolution\modX;
use MSearch\Adapters\ContentAdapterInterface;
use MSearch\MSearch;
use MSearch\Services\Searcher\ResultSet;

/**
 * Search API Controller.
 *
 * Service parameters (tpl, limit, ctx) are read from the user's PHP session
 * by formId — they are configured server-side via the mSearchForm snippet
 * and never accepted from the client query string. Only `query` (and
 * pagination `offset` for full search) are taken from the request.
 */
class SearchController extends AbstractController
{
    /** @var array<string,bool> Per-request cache for chunk existence */
    private array $chunkCache = [];

    public function search(array $input): array
    {
        $query = $this->getOptional($input, 'query', '');
        $offset = max(0, $this->getInt($input, 'offset', 0));
        $config = $this->loadFormConfig($this->getOptional($input, 'form', ''), 'search');
        $config['ctx'] = $this->resolveCtx($config['ctx'], $input);

        if (empty($query)) {
            return [
                'total' => 0,
                'limit' => $config['limit'],
                'offset' => $offset,
                'query' => '',
                'items' => [],
            ];
        }

        $resultSet = $this->msearch->search($query, [
            'limit' => $config['limit'],
            'offset' => $offset,
            'contexts' => $config['ctx'],
            'class_keys' => $config['class_keys'],
            // Статистику пишем только для реального поиска на фронте (web),
            // не для превью в админке (context=manager), и только для первой
            // страницы — иначе каждая пролистанная страница плодит +1 к счётчику.
            'log' => ($this->context === 'web') && $offset === 0,
        ]);

        $items = $this->renderItems($resultSet, $query, $config, 'result');

        return [
            'total' => $resultSet->getTotal(),
            'limit' => $config['limit'],
            'offset' => $offset,
            'query' => $resultSet->getQuery(),
            'items' => $items,
        ];
    }

    /**
     * Autocomplete suggestions for frontend
     */
    public function suggest(array $input): array
    {
        $query = $this->getOptional($input, 'query', '');
        $config = $this->loadFormConfig($this->getOptional($input, 'form', ''), 'suggest');
        $config['ctx'] = $this->resolveCtx($config['ctx'], $input);

        $minLength = max(1, (int) $this->modx->getOption('mse_suggest_min_query_length', null, 2));
        if (empty($query) || mb_strlen($query) < $minLength) {
            return ['items' => []];
        }

        $resultSet = $this->msearch->search($query, [
            'limit' => $config['limit'],
            'contexts' => $config['ctx'],
            'class_keys' => $config['class_keys'],
            // Автоподсказки не логируем: иначе статистику заполняют
            // промежуточные префиксы ввода («ай», «айф», «айфо»...).
            'log' => false,
        ]);

        if ($resultSet->isEmpty()) {
            return ['items' => []];
        }

        $items = $this->renderItems($resultSet, $query, $config, 'suggest');

        return ['items' => $items];
    }

    /**
     * Read snippet-configured tpl/limit/ctx/class_keys/element from MODX cache by formId.
     *
     * Falls back to safe defaults when the formId is missing, unknown, or
     * the cache entry has expired — anonymous clients never get to specify
     * service parameters directly.
     *
     * @return array{tpl:string, limit:int, ctx:array<int,string>, class_keys:array<int,string>, element:string, elementProperties:array<string,mixed>}
     */
    private function loadFormConfig(mixed $formIdInput, string $mode): array
    {
        $defaultLimit = $mode === 'suggest' ? 5 : 10;
        $config = [
            'tpl' => '',
            'limit' => $defaultLimit,
            'ctx' => [],
            'class_keys' => [],
            'element' => '',
            'elementProperties' => [],
            'includeTVs' => '',
            'tvPrefix' => '',
            'processTVs' => '',
            'prepareTVs' => '',
        ];

        if (!is_string($formIdInput)) {
            return $config;
        }

        $formId = trim($formIdInput);
        // Snippet generates formId via substr(md5(...), 0, 12) — match it strictly
        if ($formId === '' || !preg_match('/^[a-f0-9]{12}$/', $formId)) {
            return $config;
        }

        $stored = $this->modx->cacheManager->get($formId, ['cache_key' => 'msearch/forms']);
        if (!is_array($stored)) {
            return $config;
        }

        if (isset($stored['tpl']) && is_string($stored['tpl'])) {
            $config['tpl'] = $stored['tpl'];
        }
        if (isset($stored['limit'])) {
            $limit = (int) $stored['limit'];
            if ($limit > 0) {
                $config['limit'] = $limit;
            }
        }
        if (isset($stored['ctx']) && is_array($stored['ctx'])) {
            $config['ctx'] = array_values(array_filter(array_map('strval', $stored['ctx'])));
        }
        if (isset($stored['class_keys']) && is_array($stored['class_keys'])) {
            $config['class_keys'] = array_values(array_filter(array_map('strval', $stored['class_keys'])));
        }
        if (isset($stored['element']) && is_string($stored['element'])) {
            $config['element'] = $stored['element'];
        }
        if (isset($stored['elementProperties']) && is_array($stored['elementProperties'])) {
            $config['elementProperties'] = $stored['elementProperties'];
        }
        if (isset($stored['includeTVs']) && is_string($stored['includeTVs'])) {
            $config['includeTVs'] = $stored['includeTVs'];
        }
        if (isset($stored['tvPrefix']) && is_string($stored['tvPrefix'])) {
            $config['tvPrefix'] = $stored['tvPrefix'];
        }
        if (isset($stored['processTVs']) && is_string($stored['processTVs'])) {
            $config['processTVs'] = $stored['processTVs'];
        }
        if (isset($stored['prepareTVs']) && is_string($stored['prepareTVs'])) {
            $config['prepareTVs'] = $stored['prepareTVs'];
        }

        return $config;
    }

    /**
     * Resolve effective context filter:
     *  - if the snippet wrote a non-empty ctx into the session — that wins
     *  - otherwise accept ctx from the query string (headless / cross-origin clients)
     *
     * ctx is a plain column filter, not a service param — it is safe to expose to clients.
     *
     * @return string[]
     */
    private function resolveCtx(array $sessionCtx, array $input): array
    {
        if (!empty($sessionCtx)) {
            return $sessionCtx;
        }
        return $this->getArray($input, 'ctx');
    }

    /**
     * Render a result set as a list of items, grouped by class for batch loading.
     *
     * @param array{tpl:string,limit:int,ctx:array,element:string,elementProperties:array} $config
     * @return array<int, array{id:int,url:string,type:string,pagetitle:string,html:string,weight:float}>
     */
    private function renderItems(ResultSet $resultSet, string $query, array $config, string $mode): array
    {
        $orderedIds = $resultSet->getIds();
        if (empty($orderedIds)) {
            return [];
        }

        $indexer = $this->msearch->getIndexer();
        $grouped = $resultSet->groupByClass();

        $tplOverride = (string) ($config['tpl'] ?? '');
        $adapterOptions = [
            'element' => (string) ($config['element'] ?? ''),
            'elementProperties' => is_array($config['elementProperties'] ?? null)
                ? $config['elementProperties']
                : [],
            'includeTVs' => (string) ($config['includeTVs'] ?? ''),
            'tvPrefix' => (string) ($config['tvPrefix'] ?? ''),
            'processTVs' => (string) ($config['processTVs'] ?? ''),
            'prepareTVs' => (string) ($config['prepareTVs'] ?? ''),
        ];

        $perId = [];
        foreach ($grouped as $classKey => $ids) {
            $adapter = $this->resolveAdapter($indexer, $classKey);
            if ($adapter === null) {
                continue;
            }

            $batch = $adapter->getDisplayData($ids, $query, $adapterOptions);
            foreach ($batch as $id => $data) {
                $perId[$id] = [
                    'adapter' => $adapter,
                    'data' => $data,
                ];
            }
        }

        if (empty($perId)) {
            return [];
        }

        /** @var Fetch $pdoFetch */
        $pdoFetch = $this->modx->services->get(Fetch::class);

        $items = [];
        foreach ($orderedIds as $id) {
            if (!isset($perId[$id])) {
                continue;
            }
            /** @var ContentAdapterInterface $adapter */
            $adapter = $perId[$id]['adapter'];
            $data = $perId[$id]['data'];

            $tpl = $tplOverride !== ''
                ? $tplOverride
                : ($mode === 'suggest' ? $adapter->getDefaultSuggestTpl() : $adapter->getDefaultResultTpl());

            $data['query'] = $query;
            $data['idx'] = count($items) + 1;

            $html = $this->renderChunkSafely($pdoFetch, $tpl, $data);

            $items[] = [
                'id' => (int) $id,
                'url' => (string) ($data['url'] ?? ''),
                'type' => (string) ($data['type'] ?? ''),
                // Plain title (no <mark> highlight) — used by the admin
                // SearchPreview table. Frontend consumers ignore it and read html.
                'pagetitle' => (string) ($data['pagetitle_raw'] ?? ''),
                'html' => $html,
                'weight' => round((float) $resultSet->getWeight((int) $id), 2),
            ];
        }

        return $items;
    }

    /**
     * Find an adapter for a class_key, with fallbacks:
     *  1. Exact match for the class_key
     *  2. ResourceAdapter (handles items indexed without an explicit class_key)
     */
    private function resolveAdapter($indexer, string $classKey): ?ContentAdapterInterface
    {
        if ($classKey !== '') {
            $adapter = $indexer->getAdapter($classKey);
            if ($adapter !== null) {
                return $adapter;
            }
        }
        return $indexer->getAdapter(\MODX\Revolution\modResource::class);
    }

    /**
     * Render a chunk via pdoTools but never fall back to the placeholder dump
     * pdoTools emits when a chunk is missing — return an empty string and log instead.
     *
     * Existence is checked once per chunk name per request to avoid N×1 SELECT.
     */
    private function renderChunkSafely(Fetch $pdoFetch, string $tpl, array $data): string
    {
        if ($tpl === '') {
            return '';
        }

        if (!$this->chunkExists($tpl)) {
            return '';
        }

        return (string) $pdoFetch->getChunk($tpl, $data);
    }

    /**
     * Cached chunk existence check.
     *
     * tpl arrives from snippet config stored in MODX cache by formId — that
     * is a trusted source (only mSearchForm writes there, never the client).
     * So binding prefixes (@FILE, @INLINE, @CHUNK) are allowed: pdoTools
     * resolves them itself (reads file from disk / parses inline / fetches
     * DB chunk). We only check existence for plain chunk names — to catch
     * typos and produce a useful log message instead of pdoTools' silent
     * fallback to a placeholder dump.
     */
    private function chunkExists(string $tpl): bool
    {
        if (isset($this->chunkCache[$tpl])) {
            return $this->chunkCache[$tpl];
        }

        // Binding-prefixed tpl (@FILE chunks/foo.tpl, @INLINE ..., @CHUNK foo) —
        // trust and pass through. pdoTools will handle the actual lookup.
        if (preg_match('#^!?@[A-Z]+#', trim($tpl)) === 1) {
            return $this->chunkCache[$tpl] = true;
        }

        $exists = $this->modx->getCount(modChunk::class, ['name' => $tpl]) > 0;
        if (!$exists) {
            $this->modx->log(
                modX::LOG_LEVEL_ERROR,
                "[mSearch] Suggestion chunk not found: {$tpl}. Install the package or create the chunk manually."
            );
        }

        return $this->chunkCache[$tpl] = $exists;
    }
}

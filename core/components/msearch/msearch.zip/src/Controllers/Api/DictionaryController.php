<?php

namespace MSearch\Controllers\Api;

use MODX\Revolution\modX;
use MSearch\MSearch;

/**
 * Dictionary API Controller
 */
class DictionaryController extends AbstractController
{
    protected array $dictionaries = [
        ['dictionary' => 'ru', 'language' => 'Russian'],
        ['dictionary' => 'en', 'language' => 'English'],
        ['dictionary' => 'de', 'language' => 'German'],
        ['dictionary' => 'uk', 'language' => 'Ukrainian'],
    ];

    protected array $mirrors = [
        ['name' => 'GitHub', 'location' => 'github.com', 'mirror' => 'github'],
    ];

    public function list(array $input): array
    {
        $morphology = $this->msearch->getMorphology();

        $results = [];
        foreach ($this->dictionaries as $dict) {
            $results[] = [
                'dictionary' => $dict['dictionary'],
                'language' => $dict['language'],
                'installed' => $morphology->hasDictionary($dict['dictionary']),
            ];
        }

        return ['results' => $results];
    }

    public function mirrors(array $input): array
    {
        return ['results' => $this->mirrors];
    }

    public function install(array $input): array
    {
        $dictionary = $input['dictionary'] ?? '';
        $mirror = $input['mirror'] ?? '';

        if (empty($dictionary) || empty($mirror)) {
            throw new \Exception('Dictionary and mirror are required');
        }

        $dictsPath = $this->msearch->config['dictsPath'];
        $targetPath = $dictsPath . $dictionary . '/';

        // Create directory if not exists
        if (!is_dir($targetPath)) {
            mkdir($targetPath, 0755, true);
        }

        // Locale mapping
        $locale = $this->getLocale($dictionary);
        $localeLower = strtolower($locale);

        // Download dictionary files (phpmorphy format: token.locale.bin)
        $baseUrl = $this->getMirrorUrl($mirror, $dictionary);

        $files = [
            "common_aut.{$localeLower}.bin",
            "morph_data.{$localeLower}.bin",
            "predict_aut.{$localeLower}.bin",
            "gramtab.{$localeLower}.bin",
            "gramtab_txt.{$localeLower}.bin",
            "morph_data_header_cache.{$localeLower}.bin",
            "options.{$localeLower}.ini",
        ];

        // Russian has additional files
        if ($dictionary === 'ru') {
            $files[] = "morph_data_ancodes_cache.{$localeLower}.bin";
            $files[] = "morph_data_ancodes_map.{$localeLower}.bin";
        }

        foreach ($files as $file) {
            $url = $baseUrl . $file;
            $content = $this->downloadFile($url);

            if ($content === false) {
                // Some files are optional
                $optional = ['gramtab_txt', 'morph_data_header_cache', 'morph_data_ancodes_cache', 'morph_data_ancodes_map', 'options'];
                $isOptional = false;
                foreach ($optional as $opt) {
                    if (str_starts_with($file, $opt)) {
                        $isOptional = true;
                        break;
                    }
                }

                if (!$isOptional) {
                    throw new \Exception("Failed to download: {$file}");
                }
                continue;
            }

            file_put_contents($targetPath . $file, $content);
        }

        return ['success' => true];
    }

    protected function downloadFile(string $url): string|false
    {
        // Try cURL first (better HTTPS support)
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_TIMEOUT => 60,
                CURLOPT_USERAGENT => 'mSearch/1.0',
            ]);
            $content = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $content !== false) {
                return $content;
            }
            return false;
        }

        // Fallback to file_get_contents
        $context = stream_context_create([
            'http' => [
                'timeout' => 60,
                'user_agent' => 'mSearch/1.0',
            ],
        ]);

        return @file_get_contents($url, false, $context);
    }

    public function remove(array $input): array
    {
        $dictionary = $input['dictionary'] ?? '';

        if (empty($dictionary)) {
            throw new \Exception('Dictionary is required');
        }

        $dictsPath = $this->msearch->config['dictsPath'];
        $targetPath = $dictsPath . $dictionary . '/';

        if (is_dir($targetPath)) {
            $files = glob($targetPath . '*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
            rmdir($targetPath);
        }

        return ['success' => true];
    }

    protected function getLocale(string $dictionary): string
    {
        return match ($dictionary) {
            'ru' => 'ru_RU',
            'en' => 'en_EN',
            'de' => 'de_DE',
            'uk' => 'uk_UA',
            default => 'ru_RU',
        };
    }

    protected function getOptionalFiles(): array
    {
        return ['gramtab_txt', 'morph_data_header_cache', 'morph_data_ancodes_cache', 'morph_data_ancodes_map', 'options', 'predict_aut'];
    }

    protected function getMirrorUrl(string $mirror, string $dictionary): string
    {
        // seoservice2020 repo has all 4 languages (ru, en, de, uk) in dicts/utf-8/
        return match ($mirror) {
            'github' => "https://raw.githubusercontent.com/seoservice2020/phpmorphy/master/dicts/utf-8/",
            default => '',
        };
    }
}

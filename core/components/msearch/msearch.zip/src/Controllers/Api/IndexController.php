<?php

namespace MSearch\Controllers\Api;

use MODX\Revolution\modX;
use MSearch\MSearch;

/**
 * Index API Controller
 */
class IndexController extends AbstractController
{

    public function stats(array $input): array
    {
        return $this->msearch->getStats();
    }

    public function create(array $input): array
    {
        $limit = (int) ($input['limit'] ?? 50);
        $offset = (int) ($input['offset'] ?? 0);

        return $this->msearch->indexBatch([
            'limit' => $limit,
            'offset' => $offset,
        ]);
    }

    public function clear(array $input): array
    {
        $this->msearch->clearIndex();

        return ['success' => true];
    }
}

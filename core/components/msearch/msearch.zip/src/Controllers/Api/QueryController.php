<?php

namespace MSearch\Controllers\Api;

use MODX\Revolution\modX;
use MSearch\Model\MseQuery;
use MSearch\MSearch;

/**
 * Query Statistics API Controller
 */
class QueryController extends AbstractController
{

    public function list(array $input): array
    {
        $c = $this->modx->newQuery(MseQuery::class);
        $c->sortby('count', 'DESC');

        $results = [];
        foreach ($this->modx->getIterator(MseQuery::class, $c) as $query) {
            $results[] = $query->toArray();
        }

        return ['results' => $results];
    }

    public function remove(array $input): array
    {
        $id = (int) ($input['id'] ?? 0);

        $query = $this->modx->getObject(MseQuery::class, $id);
        if ($query) {
            $query->remove();
        }

        return ['success' => true];
    }

    public function removeAll(array $input): array
    {
        $this->modx->removeCollection(MseQuery::class, []);

        return ['success' => true];
    }
}

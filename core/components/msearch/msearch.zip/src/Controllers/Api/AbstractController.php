<?php

namespace MSearch\Controllers\Api;

use MODX\Revolution\modX;
use MSearch\MSearch;

/**
 * Base API Controller
 */
abstract class AbstractController
{
    protected modX $modx;
    protected MSearch $msearch;
    /**
     * @var string Контекст запроса, выставляется Router'ом: web|manager.
     * Безопасный дефолт — manager: статистика пишется только когда Router
     * явно выставил web, а не при создании контроллера в обход Router.
     */
    protected string $context = 'manager';

    public function __construct(modX $modx, MSearch $msearch)
    {
        $this->modx = $modx;
        $this->msearch = $msearch;
    }

    public function setContext(string $context): void
    {
        $this->context = $context;
    }

    protected function success(array $data): array
    {
        return array_merge(['success' => true], $data);
    }

    protected function error(string $message, int $code = 400): array
    {
        return ['success' => false, 'message' => $message, 'code' => $code];
    }

    protected function getRequired(array $data, string $key): mixed
    {
        if (!isset($data[$key]) || $data[$key] === '') {
            throw new \InvalidArgumentException("Parameter '{$key}' is required");
        }
        return $data[$key];
    }

    protected function getOptional(array $data, string $key, $default = null): mixed
    {
        return $data[$key] ?? $default;
    }

    protected function getInt(array $data, string $key, int $default = 0): int
    {
        return (int) ($data[$key] ?? $default);
    }

    protected function getBool(array $data, string $key, bool $default = false): bool
    {
        if (!isset($data[$key])) {
            return $default;
        }
        return filter_var($data[$key], FILTER_VALIDATE_BOOLEAN);
    }

    protected function getArray(array $data, string $key, array $default = []): array
    {
        $value = $data[$key] ?? $default;
        if (is_string($value)) {
            return array_filter(array_map('trim', explode(',', $value)));
        }
        return is_array($value) ? $value : $default;
    }
}

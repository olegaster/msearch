<?php

namespace MSearch\Controllers\Api;

use MODX\Revolution\modX;
use MSearch\Model\MseAlias;
use MSearch\MSearch;

/**
 * Alias API Controller
 */
class AliasController extends AbstractController
{

    public function list(array $input): array
    {
        $c = $this->modx->newQuery(MseAlias::class);
        $c->sortby('word', 'ASC');

        $results = [];
        foreach ($this->modx->getIterator(MseAlias::class, $c) as $alias) {
            $results[] = $alias->toArray();
        }

        return ['results' => $results];
    }

    public function create(array $input): array
    {
        $alias = $this->modx->newObject(MseAlias::class);
        $alias->set('word', $input['word'] ?? '');
        $alias->set('alias', $input['alias'] ?? '');
        $alias->set('replace', !empty($input['replace']));
        $alias->set('active', $input['active'] ?? true);

        if (!$alias->save()) {
            throw new \Exception('Failed to create alias');
        }

        return $alias->toArray();
    }

    public function update(array $input): array
    {
        $id = (int) ($input['id'] ?? 0);

        $alias = $this->modx->getObject(MseAlias::class, $id);
        if (!$alias) {
            throw new \Exception('Alias not found');
        }

        $alias->set('word', $input['word'] ?? $alias->get('word'));
        $alias->set('alias', $input['alias'] ?? $alias->get('alias'));
        $alias->set('replace', isset($input['replace']) ? !empty($input['replace']) : $alias->get('replace'));
        $alias->set('active', $input['active'] ?? $alias->get('active'));

        if (!$alias->save()) {
            throw new \Exception('Failed to update alias');
        }

        return $alias->toArray();
    }

    public function remove(array $input): array
    {
        $id = (int) ($input['id'] ?? 0);

        $alias = $this->modx->getObject(MseAlias::class, $id);
        if ($alias) {
            $alias->remove();
        }

        return ['success' => true];
    }
}

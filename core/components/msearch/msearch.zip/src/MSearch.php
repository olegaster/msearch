<?php

namespace MSearch;

use MODX\Revolution\modX;
use MSearch\Services\Indexer\IndexerInterface;
use MSearch\Services\Searcher\SearcherInterface;
use MSearch\Services\Morphology\MorphologyInterface;

/**
 * Main mSearch facade class
 *
 * Provides high-level API for search and indexing operations
 */
class MSearch
{
    public const VERSION = '1.4.0-beta';

    public modX $modx;
    public array $config = [];

    protected ?IndexerInterface $indexer = null;
    protected ?SearcherInterface $searcher = null;
    protected ?MorphologyInterface $morphology = null;

    public function __construct(modX $modx, array $config = [])
    {
        $this->modx = $modx;

        $corePath = $modx->getOption(
            'msearch_core_path',
            $config,
            $modx->getOption('core_path') . 'components/msearch/'
        );
        $assetsPath = $modx->getOption(
            'msearch_assets_path',
            $config,
            $modx->getOption('assets_path') . 'components/msearch/'
        );
        $assetsUrl = $modx->getOption(
            'msearch_assets_url',
            $config,
            $modx->getOption('assets_url') . 'components/msearch/'
        );

        $this->config = array_merge([
            'corePath' => $corePath,
            'srcPath' => $corePath . 'src/',
            'modelPath' => $corePath . 'src/Model/',
            'elementsPath' => $corePath . 'elements/',
            'snippetsPath' => $corePath . 'elements/snippets/',
            'chunksPath' => $corePath . 'elements/chunks/',
            'pluginsPath' => $corePath . 'elements/plugins/',
            'controllersPath' => $corePath . 'controllers/',
            'lexiconPath' => $corePath . 'lexicon/',
            'dictsPath' => $corePath . 'phpmorphy/dicts/',
            'assetsPath' => $assetsPath,
            'assetsUrl' => $assetsUrl,
            'cssUrl' => $assetsUrl . 'css/',
            'jsUrl' => $assetsUrl . 'js/',
            'connectorUrl' => $assetsUrl . 'connector.php',
        ], $config);

        $this->modx->lexicon->load('msearch:default');
    }

    /**
     * Get indexer service
     */
    public function getIndexer(): IndexerInterface
    {
        if ($this->indexer === null) {
            $this->indexer = new Services\Indexer\Indexer($this->modx, $this);
        }
        return $this->indexer;
    }

    /**
     * Get searcher service
     */
    public function getSearcher(): SearcherInterface
    {
        if ($this->searcher === null) {
            $this->searcher = new Services\Searcher\Searcher($this->modx, $this);
        }
        return $this->searcher;
    }

    /**
     * Get morphology service
     */
    public function getMorphology(): MorphologyInterface
    {
        if ($this->morphology === null) {
            $this->morphology = new Services\Morphology\PhpMorphyAdapter($this->modx, $this);
        }
        return $this->morphology;
    }

    /**
     * Search for resources
     *
     * @param string $query Search query
     * @param array $options Search options (limit, offset, etc.)
     * @return Services\Searcher\ResultSet
     */
    public function search(string $query, array $options = []): Services\Searcher\ResultSet
    {
        return $this->getSearcher()->search($query, $options);
    }

    /**
     * Index a single resource
     *
     * @param int $resourceId Resource ID
     * @return bool Success status
     */
    public function index(int $resourceId): bool
    {
        return $this->getIndexer()->indexResource($resourceId);
    }

    /**
     * Batch index resources
     *
     * @param array $options Batch options (limit, offset, classKey)
     * @return array Result with indexed count and status
     */
    public function indexBatch(array $options = []): array
    {
        return $this->getIndexer()->indexBatch($options);
    }

    /**
     * Remove resource from index
     *
     * @param int $resourceId Resource ID
     * @return bool Success status
     */
    public function removeFromIndex(int $resourceId): bool
    {
        return $this->getIndexer()->removeResource($resourceId);
    }

    /**
     * Clear entire index
     *
     * @return bool Success status
     */
    public function clearIndex(): bool
    {
        return $this->getIndexer()->clearIndex();
    }

    /**
     * Highlight search terms in text
     *
     * @param string $text Text to highlight
     * @param string $query Search query
     * @param array $options Highlight options
     * @return string Highlighted text
     */
    public function highlight(string $text, string $query, array $options = []): string
    {
        $highlighter = new Services\Highlighter\Highlighter($this->modx, $this);
        return $highlighter->highlight($text, $query, $options);
    }

    /**
     * Get index statistics
     *
     * @return array Statistics (total, indexed, words)
     */
    public function getStats(): array
    {
        return $this->getIndexer()->getStats();
    }
}

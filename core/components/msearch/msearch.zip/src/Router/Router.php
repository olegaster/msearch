<?php

namespace MSearch\Router;

use FastRoute\Dispatcher;
use FastRoute\RouteCollector;
use MODX\Revolution\modX;
use MSearch\MSearch;

/**
 * API Router for mSearch
 */
class Router
{
    protected modX $modx;
    protected MSearch $msearch;
    protected Dispatcher $dispatcher;
    protected string $context = 'manager';

    public function __construct(modX $modx)
    {
        $this->modx = $modx;
        $this->msearch = $modx->services->get('msearch');
    }

    public function setContext(string $context): void
    {
        $this->context = $context;
    }

    public function getContext(): string
    {
        return $this->context;
    }

    protected function initRoutes(): void
    {
        $context = $this->context;

        $this->dispatcher = \FastRoute\simpleDispatcher(function (RouteCollector $r) use ($context) {
            if ($context === 'web') {
                $this->registerWebRoutes($r);
            } else {
                $this->registerManagerRoutes($r);
            }
        });
    }

    protected function registerWebRoutes(RouteCollector $r): void
    {
        $r->get('/search', ['SearchController', 'search']);
        $r->get('/search/suggest', ['SearchController', 'suggest']);
    }

    protected function registerManagerRoutes(RouteCollector $r): void
    {
        // Index routes
        $r->get('/index/stats', ['IndexController', 'stats']);
        $r->post('/index/create', ['IndexController', 'create']);
        $r->post('/index/clear', ['IndexController', 'clear']);

        // Search routes (also available in manager for preview)
        $r->get('/search', ['SearchController', 'search']);
        $r->get('/search/suggest', ['SearchController', 'suggest']);

        // Query routes
        $r->get('/queries', ['QueryController', 'list']);
        $r->delete('/queries/{id:\d+}', ['QueryController', 'remove']);
        $r->delete('/queries', ['QueryController', 'removeAll']);

        // Alias routes
        $r->get('/aliases', ['AliasController', 'list']);
        $r->post('/aliases', ['AliasController', 'create']);
        $r->put('/aliases/{id:\d+}', ['AliasController', 'update']);
        $r->delete('/aliases/{id:\d+}', ['AliasController', 'remove']);

        // Dictionary routes
        $r->get('/dictionaries', ['DictionaryController', 'list']);
        $r->get('/dictionaries/mirrors', ['DictionaryController', 'mirrors']);
        $r->post('/dictionaries/install', ['DictionaryController', 'install']);
        $r->delete('/dictionaries/{dictionary}', ['DictionaryController', 'remove']);
    }

    public function handle(string $route): void
    {
        $this->initRoutes();

        $method = $_SERVER['REQUEST_METHOD'];

        $routeInfo = $this->dispatcher->dispatch($method, $route);

        switch ($routeInfo[0]) {
            case Dispatcher::NOT_FOUND:
                $this->sendError('Route not found', 404);
                break;

            case Dispatcher::METHOD_NOT_ALLOWED:
                $this->sendError('Method not allowed', 405);
                break;

            case Dispatcher::FOUND:
                [$controllerName, $action] = $routeInfo[1];
                $params = $routeInfo[2];

                $this->dispatch($controllerName, $action, $params);
                break;
        }
    }

    protected function dispatch(string $controllerName, string $action, array $params): void
    {
        $controllerClass = "MSearch\\Controllers\\Api\\{$controllerName}";

        if (!class_exists($controllerClass)) {
            $this->sendError("Controller not found: {$controllerName}", 500);
            return;
        }

        $controller = new $controllerClass($this->modx, $this->msearch);
        // Серверный контекст (web|manager) — по нему контроллер решает,
        // логировать ли запрос в статистику. Отдельным свойством, не в $input.
        $controller->setContext($this->context);

        if (!method_exists($controller, $action)) {
            $this->sendError("Action not found: {$action}", 500);
            return;
        }

        // Get request body for POST/PUT
        $input = [];
        if (in_array($_SERVER['REQUEST_METHOD'], ['POST', 'PUT'])) {
            $rawInput = file_get_contents('php://input');
            if ($rawInput) {
                $input = json_decode($rawInput, true) ?: [];
            }
            $input = array_merge($_POST, $input);
        } else {
            $input = $_GET;
        }

        $input = array_merge($input, $params);

        try {
            $result = $controller->{$action}($input);
            $this->sendSuccess($result);
        } catch (\Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }

    protected function sendSuccess($data): void
    {
        header('Content-Type: application/json');
        echo json_encode(array_merge(
            ['success' => true],
            $data
        ));
    }

    protected function sendError(string $message, int $code = 400): void
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $message,
        ]);
    }
}

<?php

namespace mSearch\Transport;

use MODX\Revolution\Transport\modTransportPackage;
use MODX\Revolution\Transport\modTransportProvider;
use xPDO\Transport\xPDOObjectVehicle;
use xPDO\Transport\xPDOTransport;
use xPDO\xPDO;

/**
 * Encrypted Vehicle for MODX3
 *
 * Encrypts package contents during build and decrypts during installation.
 * Requires valid license from modstore.pro to install.
 */
class EncryptedVehicle extends xPDOObjectVehicle
{
    public $class = 'mSearch\\Transport\\EncryptedVehicle';

    const VERSION = '3.0.0';
    const CIPHER = 'AES-256-CBC';

    const DIRECT_MODE = true;
    const VENDOR_PUBLIC_KEY = 'oVbbBN51T0O94XqD8i7Ccr5cbUB/DTqEyRrKZ9ZKaEU=';
    const PACKAGE = 'msearch';
    const AES_KEY = '0a8b23f65ad0a7b41ae76aa47a0d96e92fd76d1ef55916d404da1d2ae06ae22c';

    /**
     * Put object into transport package with encryption
     *
     * @param xPDOTransport $transport
     * @param mixed $object
     * @param array $attributes
     */
    public function put(&$transport, &$object, $attributes = [])
    {
        parent::put($transport, $object, $attributes);

        if (defined('PKG_ENCODE_KEY') && PKG_ENCODE_KEY) {
            $this->payload['object_encrypted'] = $this->encode($this->payload['object'], PKG_ENCODE_KEY);
            unset($this->payload['object']);

            if (isset($this->payload['related_objects'])) {
                $this->payload['related_objects_encrypted'] = $this->encode($this->payload['related_objects'], PKG_ENCODE_KEY);
                unset($this->payload['related_objects']);
            }

            $transport->xpdo->log(xPDO::LOG_LEVEL_INFO, 'Package encrypted!');
        }
    }

    /**
     * Install encrypted vehicle
     *
     * @param xPDOTransport $transport
     * @param array $options
     * @return bool
     */
    public function install(&$transport, $options)
    {
        if (!$this->decodePayloads($transport, 'install')) {
            return false;
        }

        $transport->xpdo->log(xPDO::LOG_LEVEL_INFO, 'Package decrypted!');

        return parent::install($transport, $options);
    }

    /**
     * Uninstall encrypted vehicle
     *
     * Decryption is attempted but not required for uninstall.
     * If decryption fails (no internet, no provider, no license),
     * parent::uninstall() still runs to process resolvers and clean up.
     *
     * @param xPDOTransport $transport
     * @param array $options
     * @return bool
     */
    public function uninstall(&$transport, $options)
    {
        if ($this->decodePayloads($transport, 'uninstall')) {
            $transport->xpdo->log(xPDO::LOG_LEVEL_INFO, 'Package decrypted!');
        } else {
            $transport->xpdo->log(
                xPDO::LOG_LEVEL_WARN,
                'Could not decrypt package for uninstall. Proceeding with resolver-based cleanup.'
            );
        }

        return parent::uninstall($transport, $options);
    }

    /**
     * Encode data with AES-256-CBC
     *
     * @param array $data
     * @param string $key
     * @return string
     */
    protected function encode($data, $key)
    {
        $ivLen = openssl_cipher_iv_length(self::CIPHER);
        $iv = openssl_random_pseudo_bytes($ivLen);
        $cipherRaw = openssl_encrypt(serialize($data), self::CIPHER, $key, OPENSSL_RAW_DATA, $iv);

        return base64_encode($iv . $cipherRaw);
    }

    /**
     * Decode data with AES-256-CBC
     *
     * @param string $string
     * @param string $key
     * @return mixed
     */
    protected function decode($string, $key)
    {
        $ivLen = openssl_cipher_iv_length(self::CIPHER);
        $encoded = base64_decode($string);

        $iv = substr($encoded, 0, $ivLen);
        $cipherRaw = substr($encoded, $ivLen);

        $decrypted = openssl_decrypt($cipherRaw, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv);

        return unserialize($decrypted);
    }

    /**
     * Decode encrypted payloads
     *
     * @param xPDOTransport $transport
     * @param string $action install|uninstall
     * @return bool
     */
    protected function decodePayloads(&$transport, $action = 'install')
    {
        if (isset($this->payload['object_encrypted']) || isset($this->payload['related_objects_encrypted'])) {
            $key = $this->getDecodeKey($transport, $action);

            if (!$key) {
                return false;
            }

            if (isset($this->payload['object_encrypted'])) {
                $this->payload['object'] = $this->decode($this->payload['object_encrypted'], $key);
                unset($this->payload['object_encrypted']);
            }

            if (isset($this->payload['related_objects_encrypted'])) {
                $this->payload['related_objects'] = $this->decode($this->payload['related_objects_encrypted'], $key);
                unset($this->payload['related_objects_encrypted']);
            }
        }

        return true;
    }

    /**
     * Get decode key from modstore.pro
     *
     * @param xPDOTransport $transport
     * @param string $action
     * @return string|false
     */
    protected function getDecodeKey(&$transport, $action)
    {
        if (self::DIRECT_MODE) {
            return $this->getDirectDecodeKey($transport, $action);
        }

        $key = false;
        $endpoint = 'package/decode/' . $action;

        /** @var modTransportPackage $package */
        $package = $transport->xpdo->getObject(modTransportPackage::class, [
            'signature' => $transport->signature,
        ]);

        if ($package instanceof modTransportPackage) {
            /** @var modTransportProvider $provider */
            $provider = $package->getOne('Provider');

            if ($provider) {
                $provider->xpdo->setOption('contentType', 'default');

                $params = [
                    'package' => $package->package_name,
                    'version' => $transport->version,
                    'username' => $provider->username,
                    'api_key' => $provider->api_key,
                    'vehicle_version' => self::VERSION,
                ];

                $response = $provider->request($endpoint, 'POST', $params);

                // MODX3 returns PSR-7 Response or false on connection error
                if ($response === false) {
                    $transport->xpdo->log(xPDO::LOG_LEVEL_ERROR, 'Failed to connect to license server');
                } elseif ($response->getStatusCode() >= 400) {
                    $transport->xpdo->log(xPDO::LOG_LEVEL_ERROR, 'License API error: HTTP ' . $response->getStatusCode());
                } else {
                    // Parse XML response
                    $body = (string) $response->getBody();
                    $data = @simplexml_load_string($body);

                    if ($data === false) {
                        $transport->xpdo->log(xPDO::LOG_LEVEL_ERROR, 'Invalid XML response from license server');
                    } elseif (!empty($data->key)) {
                        $key = (string) $data->key;
                    } elseif (!empty($data->message)) {
                        $transport->xpdo->log(xPDO::LOG_LEVEL_ERROR, (string) $data->message);
                    }
                }
            } else {
                $transport->xpdo->log(xPDO::LOG_LEVEL_ERROR,
                    'Package provider not found. Please select modstore.pro as provider before installation.');
            }
        }

        return $key;
    }

    protected function getDirectDecodeKey(&$transport, $action)
    {
        $token = trim((string) $transport->xpdo->getOption('mse_license', null, ''));

        if ($token === '') {
            $setting = $transport->xpdo->getObject(\MODX\Revolution\modSystemSetting::class, ['key' => 'mse_license']);
            if ($setting) {
                $token = trim((string) $setting->get('value'));
            }
        }

        if ($token === '') {
            /** @var modTransportPackage $package */
            $package = $transport->xpdo->getObject(modTransportPackage::class, ['signature' => $transport->signature]);
            if ($package instanceof modTransportPackage) {
                /** @var modTransportProvider $provider */
                $provider = $package->getOne('Provider');
                if ($provider) {
                    $token = trim((string) $provider->api_key);
                }
            }
        }

        if ($token === '') {
            $transport->xpdo->log(xPDO::LOG_LEVEL_ERROR,
                '[mSearch] Лицензия не найдена. Создайте системную настройку mse_license со значением лицензионного ключа и повторите установку.');
            return false;
        }

        $host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : '';
        $data = self::verifyLicense($token, self::VENDOR_PUBLIC_KEY, self::PACKAGE, $host);

        if ($data === false) {
            $transport->xpdo->log(xPDO::LOG_LEVEL_ERROR,
                '[mSearch] Проверка лицензии не пройдена (подпись, домен или срок). Текущий домен: ' . ($host !== '' ? $host : '(не определён)'));
            return false;
        }

        $transport->xpdo->log(xPDO::LOG_LEVEL_INFO, '[mSearch] Лицензия подтверждена для домена: ' . $host);

        return self::AES_KEY;
    }

    public static function verifyLicense($token, $pubKeyB64, $package, $host)
    {
        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            return false;
        }

        $parts = explode('.', (string) $token);
        if (count($parts) !== 2) {
            return false;
        }

        $payloadJson = self::b64urlDecode($parts[0]);
        $sig = self::b64urlDecode($parts[1]);
        $pub = base64_decode($pubKeyB64, true);

        if ($payloadJson === false || $sig === false || $pub === false) {
            return false;
        }
        if (strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            return false;
        }
        if (!sodium_crypto_sign_verify_detached($sig, $payloadJson, $pub)) {
            return false;
        }

        $data = json_decode($payloadJson, true);
        if (!is_array($data)) {
            return false;
        }
        if (($data['package'] ?? '') !== $package) {
            return false;
        }
        if (!empty($data['expires'])) {
            $exp = strtotime((string) $data['expires']);
            if ($exp !== false && time() > $exp) {
                return false;
            }
        }
        $domains = $data['domains'] ?? [];
        if (!is_array($domains) || !self::hostAllowed($host, $domains)) {
            return false;
        }

        return $data;
    }

    protected static function normalizeHost($h)
    {
        $h = strtolower(trim((string) $h));
        $h = preg_replace('#^https?://#', '', $h);
        $h = explode('/', $h)[0];
        $h = explode(':', $h)[0];
        return $h;
    }

    protected static function hostAllowed($host, array $domains)
    {
        $host = self::normalizeHost($host);
        if ($host === '') {
            return false;
        }
        foreach ($domains as $d) {
            $d = self::normalizeHost($d);
            if ($d === '') {
                continue;
            }
            if ($host === $d || $host === 'www.' . $d) {
                return true;
            }
            foreach (['dev', 'test'] as $p) {
                if ($host === $p . '.' . $d) {
                    return true;
                }
                for ($n = 1; $n <= 10; $n++) {
                    if ($host === $p . $n . '.' . $d) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    protected static function b64urlDecode($s)
    {
        $s = strtr((string) $s, '-_', '+/');
        $pad = strlen($s) % 4;
        if ($pad) {
            $s .= str_repeat('=', 4 - $pad);
        }
        return base64_decode($s, true);
    }
}

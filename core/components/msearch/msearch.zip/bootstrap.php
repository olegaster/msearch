<?php

/**
 * mSearch Bootstrap
 *
 * @var \MODX\Revolution\modX $modx
 * @var array $namespace
 */

// Load composer autoload
require_once $namespace['path'] . 'vendor/autoload.php';

// Load the xPDO models
$modx->addPackage('MSearch\Model', $namespace['path'] . 'src/', null, 'MSearch\\');

// Register main service
$modx->services->add('msearch', function ($c) use ($modx) {
    return new MSearch\MSearch($modx);
});

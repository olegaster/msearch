<?php
/**
 * mSearchForm snippet
 *
 * Renders a search form and (optionally) configures autocomplete.
 *
 * Service parameters (tpl, limit, ctx) are written into the user's session
 * under a deterministic formId. The autocomplete API reads them by formId
 * — they NEVER travel through the query string. Only `query` is accepted
 * from the client side.
 *
 * @var modX $modx
 * @var array $scriptProperties
 *
 * @property string $tplForm Chunk name for the form itself (default: mSearch.form)
 * @property string $tpl Chunk name for one autocomplete suggestion row (default: mSearch.suggest.row)
 * @property int $limit Maximum number of suggestions (default: 5)
 * @property string $ctx Comma-separated context keys to filter by (default: current context)
 * @property string $classKey Comma-separated class_keys to restrict search to (default: empty — all classes)
 * @property string $queryVar Name of the request parameter that carries the search query (default: mse_query)
 * @property string $element Name of an external snippet (e.g. msProducts) that loads suggestion rows. Adapter calls it via runSnippet and enriches the result. Empty = use adapter's native loader.
 * @property string $elementProperties JSON object with extra properties to pass to $element. Reserved keys `resources` and `return` are always overridden by the adapter.
 * @property string $includeTVs Comma-separated TV names to load into suggestions. Appear as placeholders in the chunk, text TVs are highlighted.
 * @property string $tvPrefix Prefix for TV placeholders (default empty). Use a no-dot prefix like `tv_` if a TV name clashes with a resource field.
 * @property string $processTVs Comma-separated TVs to render through their output (image/file baseUrl, output filters). Off by default.
 * @property string $prepareTVs Comma-separated TVs to pre-process before output. Off by default.
 * @property string $pageId Target page ID for search results
 * @property int $autocomplete Enable autocomplete
 */

use ModxPro\PdoTools\Fetch;

/** @var MSearch\MSearch $msearch */
$msearch = $modx->services->get('msearch');
$pdoFetch = $modx->services->get(Fetch::class);

$tplForm = $scriptProperties['tplForm'] ?? 'mSearch.form';
$tplRow = $scriptProperties['tpl'] ?? 'mSearch.suggest.row';
$limit = (int) ($scriptProperties['limit'] ?? 5);
if ($limit < 1) {
    $limit = 5;
}

$ctxRaw = trim((string) ($scriptProperties['ctx'] ?? ''));
if ($ctxRaw === '') {
    $ctxRaw = (string) ($modx->context->key ?? 'web');
}
$ctxList = array_values(array_filter(array_map('trim', explode(',', $ctxRaw))));

// Optional class_key filter — restrict search to one or more classes.
// Accepts: PHP array (Fenom call) or comma-separated string (MODX tag).
$classKeyRaw = $scriptProperties['classKey'] ?? '';
if (is_array($classKeyRaw)) {
    $classKeyList = array_values(array_filter(array_map('strval', $classKeyRaw)));
} else {
    $classKeyList = array_values(array_filter(array_map('trim', explode(',', (string) $classKeyRaw))));
}

$pageId = $scriptProperties['pageId'] ?? ($modx->resource ? $modx->resource->get('id') : 0);
$autocomplete = !empty($scriptProperties['autocomplete']);

$queryVar = trim((string) ($scriptProperties['queryVar'] ?? 'mse_query'));
if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $queryVar)) {
    $queryVar = 'mse_query';
}

// External snippet integration. `element` names a snippet (e.g. msProducts)
// that the adapter will runSnippet() for data — gives access to its events,
// discount plugins, currency formatting. `elementProperties` accepts either
// a JSON string (standard MODX tag syntax) or a PHP array (Fenom `| snippet`
// filter and programmatic calls).
$element = trim((string) ($scriptProperties['element'] ?? ''));
$elementProperties = [];
$elementPropertiesRaw = $scriptProperties['elementProperties'] ?? '';
if (is_array($elementPropertiesRaw)) {
    $elementProperties = $elementPropertiesRaw;
} elseif (is_string($elementPropertiesRaw) && $elementPropertiesRaw !== '') {
    $decoded = json_decode($elementPropertiesRaw, true);
    if (is_array($decoded)) {
        $elementProperties = $decoded;
    } else {
        $modx->log(
            \MODX\Revolution\modX::LOG_LEVEL_ERROR,
            '[mSearch] Invalid elementProperties JSON in mSearchForm: ' . json_last_error_msg()
        );
    }
}

// TV loading for resource suggestions (ResourceAdapter uses pdoFetch includeTVs).
$includeTVs = trim((string) ($scriptProperties['includeTVs'] ?? ''));
$tvPrefix   = (string) ($scriptProperties['tvPrefix'] ?? '');
// processTVs/prepareTVs — pdoFetch TV rendering (image/file baseUrl, output filters).
$processTVs = trim((string) ($scriptProperties['processTVs'] ?? ''));
$prepareTVs = trim((string) ($scriptProperties['prepareTVs'] ?? ''));

$query = $_REQUEST[$queryVar] ?? '';
$url = $modx->makeUrl((int) $pageId, '', '', 'full');
$connectorUrl = $msearch->config['assetsUrl'] . 'api.php';

// Deterministic ID for this snippet instance — different properties → different ID
$config = [
    'tpl' => $tplRow,
    'limit' => $limit,
    'ctx' => $ctxList,
    'class_keys' => $classKeyList,
    'element' => $element,
    'elementProperties' => $elementProperties,
    'includeTVs' => $includeTVs,
    'tvPrefix' => $tvPrefix,
    'processTVs' => $processTVs,
    'prepareTVs' => $prepareTVs,
];
$formId = substr(md5(serialize($config)), 0, 12);

// Persist config in MODX cache so the autocomplete API can read it without
// trusting any client-supplied values. Cache (not session) because the
// config is fully derived from snippet properties — no per-user secret —
// and a global key avoids unbounded $_SESSION growth.
if ($autocomplete) {
    $modx->cacheManager->set(
        $formId,
        $config,
        86400,
        ['cache_key' => 'msearch/forms']
    );
}

$fields = [
    'query' => htmlspecialchars($query, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
    'queryVar' => $queryVar,
    'action' => $url,
    'autocomplete' => $autocomplete ? 'true' : 'false',
    'connectorUrl' => $connectorUrl,
    'formId' => $formId,
];

// Frontend assets
$assetsUrl = $msearch->config['assetsUrl'];
$cssUrl = $modx->getOption('mse_frontend_css');
if ($cssUrl) {
    $cssUrl = str_replace('[[++assets_url]]', MODX_ASSETS_URL, $cssUrl);
    $cssUrl = str_replace('{$assets_url}', MODX_ASSETS_URL, $cssUrl);
    $modx->regClientCSS($cssUrl);
}

if ($autocomplete) {
    $jsBase = $assetsUrl . 'js/web/';
    $modx->regClientScript($jsBase . 'core/ApiClient.js');
    $modx->regClientScript($jsBase . 'core/SearchAPI.js');
    $modx->regClientScript($jsBase . 'modules/hooks.js');
    $modx->regClientScript($jsBase . 'msearch.headless.js');
    $modx->regClientScript($jsBase . 'ui/SearchUI.js');
    $modx->regClientScript($jsBase . 'msearch.js');

    // Only public values go to JS — connector URL and auto-init flag.
    // Service params (tpl/limit/ctx) are NOT exposed to the client.
    $jsConfig = json_encode([
        'apiUrl' => $connectorUrl,
        'autoInit' => true,
        // Серверный порог длины запроса — чтобы клиент не слал заведомо
        // пустые для сервера запросы. На форме можно переопределить
        // атрибутом data-min-query-length.
        'minQueryLength' => max(1, (int) $modx->getOption('mse_suggest_min_query_length', null, 2)),
    ], JSON_HEX_TAG | JSON_UNESCAPED_UNICODE);
    $modx->regClientScript("<script>window.msearchConfig = {$jsConfig};</script>", true);
}

return $pdoFetch->getChunk($tplForm, $fields);

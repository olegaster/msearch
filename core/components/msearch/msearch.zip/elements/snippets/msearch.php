<?php
/**
 * mSearch snippet
 *
 * @var modX $modx
 * @var array $scriptProperties
 *
 * @property string $query Search query
 * @property string $queryVar Name of the request parameter to read the query from (default: mse_query)
 * @property string $tpl Chunk name for result row
 * @property int $limit Limit results
 * @property int $offset Offset for pagination
 * @property string $outputSeparator Output separator
 * @property string $toPlaceholder Set results to placeholder
 * @property string $tplWrapper Wrapper chunk
 */

use ModxPro\PdoTools\Fetch;

$msearch = $modx->services->get('msearch');
$pdoFetch = $modx->services->get(Fetch::class);

$queryVar = trim((string) ($scriptProperties['queryVar'] ?? 'mse_query'));
if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $queryVar)) {
    $queryVar = 'mse_query';
}

$query = trim($_REQUEST[$queryVar] ?? $scriptProperties['query'] ?? '');
$tpl = $scriptProperties['tpl'] ?? 'mSearch.row';
$tplWrapper = $scriptProperties['tplWrapper'] ?? '';
$limit = (int) ($scriptProperties['limit'] ?? 10);
$offset = max(0, (int) ($scriptProperties['offset'] ?? 0));
$toPlaceholder = $scriptProperties['toPlaceholder'] ?? '';
$return = $scriptProperties['return'] ?? 'chunks';
// Логировать запрос в статистику, только если логирование разрешено
// (&log, по умолчанию да) И это первая страница. Первую страницу определяем
// и по offset (element=mSearch), и по номеру страницы pdoPage (return=ids +
// pdoResources, где mSearch каждый раз зовётся с offset=0). Служебные вызовы
// глушатся явным &log=`0`.
$pageVar = (string) ($scriptProperties['pageVarKey'] ?? 'page');
$page = (int) ($_REQUEST[$pageVar] ?? 1);
$log = filter_var($scriptProperties['log'] ?? true, FILTER_VALIDATE_BOOLEAN)
    && ($offset === 0)
    && ($page <= 1);

// Context filtering: default to current context
$contexts = [];
if (!empty($scriptProperties['contexts'])) {
    $contexts = array_filter(array_map('trim', explode(',', $scriptProperties['contexts'])));
} else {
    $contexts = [$modx->context->key ?? 'web'];
}

$modx->setPlaceholder('mse.query', $query);

if (empty($query)) {
    $modx->setPlaceholder('mse.total', 0);
    if (!empty($scriptProperties['totalVar'])) {
        $modx->setPlaceholder($scriptProperties['totalVar'], 0);
    }
    return '';
}

$resultSet = $msearch->search($query, ['limit' => $limit, 'offset' => $offset, 'contexts' => $contexts, 'log' => $log]);
$modx->setPlaceholder('mse.total', $resultSet->getTotal());
// pdoPage и другие обёртки читают общее число из переданного ими totalVar
// (по умолчанию page.total) — без этого навигация увидит 0.
if (!empty($scriptProperties['totalVar'])) {
    $modx->setPlaceholder($scriptProperties['totalVar'], $resultSet->getTotal());
}

if ($resultSet->isEmpty()) {
    return '';
}

$found = $resultSet->toArray();
$ids = array_keys($found);

// Return IDs only
if ($return === 'ids') {
    $output = implode(',', $ids);
    if ($toPlaceholder) {
        $modx->setPlaceholder($toPlaceholder, $output);
        return '';
    }
    return $output;
}

$resources = implode(',', $ids);

$class = 'MODX\\Revolution\\modResource';
$pdoFetch->setConfig([
    'class' => $class,
    'resources' => $resources,
    'return' => 'data',
    // resources уже срезаны по странице и упорядочены по весу в Searcher.
    // sortby=ids сохраняет этот порядок; limit/offset обнуляем, чтобы pdoFetch
    // не резал выборку повторно.
    'sortby' => 'ids',
    'limit' => 0,
    'offset' => 0,
]);
$rows = $pdoFetch->run();

// Add weight and intro to rows
foreach ($rows as &$row) {
    $row['weight'] = $found[$row['id']] ?? 0;
    $row['intro'] = $msearch->highlight($row['introtext'] ?? '', $query, ['ellipsisLength' => 200]);
}
unset($row);

// Return JSON
if ($return === 'json') {
    $output = json_encode($rows, JSON_UNESCAPED_UNICODE);
    if ($toPlaceholder) {
        $modx->setPlaceholder($toPlaceholder, $output);
        return '';
    }
    return $output;
}

// Return raw data (for other snippets)
if ($return === 'data') {
    return $rows;
}

// Frontend CSS — нужен для разметки подсветки (<mark class="mse-highlight">).
// Регистрируется только при выводе HTML (не для ids/json/data — они вышли выше).
// regClientCSS дедуплицирует по URL: если на странице есть mSearchForm с тем же
// mse_frontend_css, второй <link> не добавится.
$cssUrl = $modx->getOption('mse_frontend_css');
if ($cssUrl) {
    $cssUrl = str_replace('[[++assets_url]]', MODX_ASSETS_URL, $cssUrl);
    $cssUrl = str_replace('{$assets_url}', MODX_ASSETS_URL, $cssUrl);
    $modx->regClientCSS($cssUrl);
}

// Return chunks (default)
$outputSeparator = $scriptProperties['outputSeparator'] ?? "\n";
// Сквозная нумерация с учётом страницы: на второй странице idx начнётся
// с offset+1, а не с 1.
$idx = $offset;
$parts = [];
foreach ($rows as $row) {
    $row['idx'] = ++$idx;
    $parts[] = $pdoFetch->getChunk($tpl, $row);
}
$output = implode($outputSeparator, $parts);

if ($tplWrapper && $output) {
    $output = $pdoFetch->getChunk($tplWrapper, [
        'output' => $output,
        'total' => $resultSet->getTotal(),
        'query' => $query,
        'offset' => $offset,
        'limit' => $limit,
    ]);
}

if ($toPlaceholder) {
    $modx->setPlaceholder($toPlaceholder, $output);
    return '';
}

return $output;

{if $type == 'product'}
    <a href="{$url}" class="mse-suggest-item mse-suggest-item--product" data-id="{$id}" data-idx="{$idx}">
        {if $thumb?}
            <img class="mse-suggest-thumb" src="{$thumb}" alt="{$pagetitle_raw | escape}" loading="lazy">
        {/if}
        <span class="mse-suggest-body">
            <span class="mse-suggest-title">{$pagetitle}</span>
            {if $article?}
                <span class="mse-suggest-article">{$article}</span>
            {/if}
            {if $price_display?}
                <span class="mse-suggest-price">
                    <span class="mse-suggest-price-current">{$price_display}</span>
                    {if $has_discount}
                        <span class="mse-suggest-price-old">{$old_price_display}</span>
                    {/if}
                </span>
            {/if}
        </span>
    </a>
{else}
    <a href="{$url}" class="mse-suggest-item mse-suggest-item--{$type}" data-id="{$id}" data-idx="{$idx}">
        <span class="mse-suggest-title">{$pagetitle}</span>
        {if $intro?}
            <span class="mse-suggest-intro">{$intro}</span>
        {/if}
    </a>
{/if}

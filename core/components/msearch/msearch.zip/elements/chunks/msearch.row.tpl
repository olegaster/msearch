<div class="mse-result" data-idx="{$idx}">
    <h3 class="mse-result-title">
        <a href="{$id | url}">{$pagetitle}</a>
    </h3>
    {if $intro?}
        <p class="mse-result-intro">{$intro}</p>
    {/if}
    <div class="mse-result-meta">
        <span class="mse-result-date">{$publishedon | date : 'd.m.Y'}</span>
        {if $weight?}
            <span class="mse-result-weight">{'mse_weight' | lexicon}: {$weight | number : 2}</span>
        {/if}
    </div>
</div>

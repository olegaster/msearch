<div class="mse-results">
    <div class="mse-results-header">
        <p class="mse-results-info">{'mse_results_found' | lexicon : ['total' => $total, 'query' => $query]}</p>
    </div>
    <div class="mse-results-list">
        {$output}
    </div>
</div>

<?php
/**
 * Scheduler task for indexing resources
 *
 * Without parameters: indexes ALL resources
 * With resource_id: indexes single resource
 *
 * @var modX $modx
 * @var array $scriptProperties
 */

// Load mSearch service
if (!$modx->services->has('msearch')) {
    $modx->log(
        modX::LOG_LEVEL_ERROR,
        "[mSearch indexResource task] mSearch service not available"
    );
    return false;
}

/** @var \MSearch\MSearch $msearch */
$msearch = $modx->services->get('msearch');

// Check if single resource or full reindex
$resourceId = $scriptProperties['resource_id'] ?? null;

if ($resourceId) {
    // Single resource indexing
    $resource = $modx->getObject(\MODX\Revolution\modResource::class, ['id' => $resourceId]);

    if (!$resource) {
        $modx->log(
            modX::LOG_LEVEL_ERROR,
            "[mSearch indexResource task] Resource #{$resourceId} not found"
        );
        return false;
    }

    // Check if resource should be indexed
    if (!$resource->get('published') || $resource->get('deleted') || !$resource->get('searchable')) {
        $msearch->removeFromIndex($resourceId);
        $modx->log(
            modX::LOG_LEVEL_INFO,
            "[mSearch indexResource task] Resource #{$resourceId} removed from index"
        );
        return true;
    }

    try {
        $result = $msearch->index($resourceId);
        $modx->log(
            modX::LOG_LEVEL_INFO,
            "[mSearch indexResource task] Resource #{$resourceId} " . ($result ? 'indexed' : 'failed')
        );
        return $result;
    } catch (\Throwable $e) {
        $modx->log(
            modX::LOG_LEVEL_ERROR,
            "[mSearch indexResource task] Exception: " . $e->getMessage()
        );
        return false;
    }
}

// Full reindex - index all resources
$modx->log(
    modX::LOG_LEVEL_INFO,
    "[mSearch indexResource task] Starting full reindex..."
);

$batchSize = 100;
$offset = 0;
$totalIndexed = 0;

try {
    do {
        $result = $msearch->indexBatch([
            'limit' => $batchSize,
            'offset' => $offset,
        ]);

        $totalIndexed += $result['indexed'];
        $offset = $result['offset'];
        $done = $result['done'] ?? ($offset >= $result['total']);

        $modx->log(
            modX::LOG_LEVEL_INFO,
            "[mSearch indexResource task] Progress: {$offset}/{$result['total']} (indexed: {$totalIndexed})"
        );

    } while (!$done);

    $modx->log(
        modX::LOG_LEVEL_INFO,
        "[mSearch indexResource task] Full reindex completed. Total indexed: {$totalIndexed}"
    );

    return true;
} catch (\Throwable $e) {
    $modx->log(
        modX::LOG_LEVEL_ERROR,
        "[mSearch indexResource task] Exception during full reindex: " . $e->getMessage()
    );
    return false;
}

<?php
/**
 * mSearch Plugin
 *
 * @var modX $modx
 * @var array $scriptProperties
 *
 * @event OnDocFormSave
 * @event OnResourceDelete
 * @event OnEmptyTrash
 */

/** @var MSearch\MSearch $msearch */
$msearch = $modx->services->get('msearch');

switch ($modx->event->name) {
    case 'OnDocFormSave':
        // Index resource on save
        /** @var modResource $resource */
        $resource = $scriptProperties['resource'];
        $id = $resource->get('id');

        if ($resource->get('published') && !$resource->get('deleted') && $resource->get('searchable')) {
            // Check if using Scheduler
            $useScheduler = $modx->getOption('mse_use_scheduler', null, false);

            if ($useScheduler && $modx->services->has('scheduler')) {
                /** @var \Scheduler $scheduler */
                $scheduler = $modx->services->get('scheduler');
                $task = $scheduler->getTask('msearch', 'mse_index_resource');

                if ($task) {
                    // Schedule task to run immediately
                    $task->schedule('+0 seconds', ['resource_id' => $id]);
                } else {
                    // Task not registered, fall back to direct indexing
                    $modx->log(
                        modX::LOG_LEVEL_ERROR,
                        '[mSearch] Scheduler task mse_index_resource not found, using direct indexing'
                    );
                    $msearch->index($id);
                }
            } else {
                // Direct indexing
                $msearch->index($id);
            }
        } else {
            // Remove from index if unpublished or deleted
            $msearch->removeFromIndex($id);
        }
        break;

    case 'OnResourceDelete':
        // Remove from index on delete
        $id = $scriptProperties['id'] ?? 0;
        if ($id) {
            $msearch->removeFromIndex($id);
        }
        break;

    case 'OnEmptyTrash':
        // Resources are already removed from index via OnResourceDelete
        break;
}

return;

<?php
/**
 * mSearch English Lexicon
 */

$_lang['msearch'] = 'mSearch';
$_lang['mse_menu_desc'] = 'Full-text search with morphological analysis';

// Tabs
$_lang['mse_tab_search'] = 'Search';
$_lang['mse_tab_search_intro'] = 'Test search queries';
$_lang['mse_tab_index'] = 'Index';
$_lang['mse_tab_index_intro'] = 'Manage search index';
$_lang['mse_tab_queries'] = 'Queries';
$_lang['mse_tab_queries_intro'] = 'Search query statistics';
$_lang['mse_tab_aliases'] = 'Aliases';
$_lang['mse_tab_aliases_intro'] = 'Synonyms and replacements for search';
$_lang['mse_tab_dictionaries'] = 'Dictionaries';
$_lang['mse_tab_dictionaries_intro'] = 'Manage morphological dictionaries';

// Index
$_lang['mse_index_total'] = 'Total resources';
$_lang['mse_index_indexed'] = 'Indexed';
$_lang['mse_index_words'] = 'Words in index';
$_lang['mse_index_limit'] = 'Batch size';
$_lang['mse_index_offset'] = 'Offset';
$_lang['mse_index_create'] = 'Create index';
$_lang['mse_index_clear'] = 'Clear index';
$_lang['mse_index_clear_confirm'] = 'Are you sure you want to clear the entire search index?';
$_lang['mse_indexing'] = 'Indexing...';
$_lang['mse_indexing_progress'] = 'Indexed [[+indexed]] of [[+total]]';

// Queries
$_lang['mse_query'] = 'Query';
$_lang['mse_query_count'] = 'Count';
$_lang['mse_query_results'] = 'Results';
$_lang['mse_query_found'] = 'Found';
$_lang['mse_query_created'] = 'Created';
$_lang['mse_query_remove'] = 'Remove';
$_lang['mse_query_remove_all'] = 'Remove all';
$_lang['mse_query_remove_confirm'] = 'Are you sure you want to remove this query?';
$_lang['mse_query_remove_all_confirm'] = 'Are you sure you want to remove all query statistics?';

// Common
$_lang['mse_yes'] = 'Yes';
$_lang['mse_no'] = 'No';
$_lang['mse_confirm_accept'] = 'Yes';
$_lang['mse_confirm_reject'] = 'Cancel';
$_lang['mse_cancel'] = 'Cancel';
$_lang['mse_save'] = 'Save';
$_lang['mse_install'] = 'Install';
$_lang['mse_replace'] = 'Replace';
$_lang['mse_add'] = 'Add';

// Aliases
$_lang['mse_alias'] = 'Alias';
$_lang['mse_alias_word'] = 'Word';
$_lang['mse_alias_replacement'] = 'Replacement';
$_lang['mse_alias_replace'] = 'Full replace';
$_lang['mse_alias_replace_desc'] = 'If enabled, the word will be fully replaced. Otherwise, the replacement will be added as a synonym.';
$_lang['mse_alias_active'] = 'Active';
$_lang['mse_alias_create'] = 'Create alias';
$_lang['mse_alias_update'] = 'Update alias';
$_lang['mse_alias_remove'] = 'Remove alias';
$_lang['mse_alias_remove_confirm'] = 'Are you sure you want to remove this alias?';

// Dictionaries
$_lang['mse_dictionary'] = 'Dictionary';
$_lang['mse_dictionary_language'] = 'Language';
$_lang['mse_dictionary_installed'] = 'Installed';
$_lang['mse_dictionary_install'] = 'Install dictionary';
$_lang['mse_dictionary_remove'] = 'Remove dictionary';
$_lang['mse_dictionary_mirror'] = 'Mirror';
$_lang['mse_dictionary_mirror_select'] = 'Select download mirror';
$_lang['mse_dictionary_downloading'] = 'Downloading dictionary...';

// Search preview
$_lang['mse_search_query'] = 'Search query';
$_lang['mse_search_button'] = 'Search';
$_lang['mse_search_results'] = 'Search results';
$_lang['mse_search_no_results'] = 'No results found';
$_lang['mse_search_result_id'] = 'ID';
$_lang['mse_search_result_title'] = 'Title';
$_lang['mse_search_result_weight'] = 'Weight';

// Errors
$_lang['mse_error'] = 'Error';
$_lang['mse_vuetools_required'] = 'VueTools package (>= 1.2.0) is required for mSearch. Please install or update it via Package Manager.';
$_lang['mse_err_query_required'] = 'Please enter a search query';
$_lang['mse_err_word_required'] = 'Please specify a word';
$_lang['mse_err_alias_required'] = 'Please specify an alias';

// Frontend
$_lang['mse_search_placeholder'] = 'Search...';
$_lang['mse_weight'] = 'Relevance';
$_lang['mse_results_found'] = 'Found [[+total]] results for "[[+query]]"';

// Snippet properties
$_lang['mse_prop_query'] = 'Search query. Defaults to $_REQUEST[queryVar]';
$_lang['mse_prop_queryVar'] = 'Name of the HTTP parameter that carries the search query (default: mse_query). Useful for migrations or alternate forms.';
$_lang['mse_prop_tpl'] = 'Chunk for rendering a single result';
$_lang['mse_prop_limit'] = 'Number of results per page';
$_lang['mse_prop_offset'] = 'Offset for pagination';
$_lang['mse_prop_log'] = 'Log the query in search statistics (only the first page is logged)';
$_lang['mse_prop_outputSeparator'] = 'Separator between results';
$_lang['mse_prop_toPlaceholder'] = 'Placeholder name for output';
$_lang['mse_prop_tplWrapper'] = 'Wrapper chunk for all results';
$_lang['mse_prop_form_tpl'] = 'Search form chunk (legacy alias, kept for compatibility)';
$_lang['mse_prop_tplForm'] = 'Search form chunk (default: mSearch.form)';
$_lang['mse_prop_form_suggest_tpl'] = 'Autocomplete suggestion row chunk (default: mSearch.suggest.row)';
$_lang['mse_prop_form_suggest_limit'] = 'Maximum number of autocomplete suggestions (default: 5)';
$_lang['mse_prop_form_ctx'] = 'Comma-separated context keys to filter search by (default: current context)';
$_lang['mse_prop_form_classKey'] = 'Comma-separated class_keys to restrict search to (default: empty — all classes). E.g. MiniShop3\\Model\\msProduct';
$_lang['mse_prop_form_element'] = 'Name of an external snippet (e.g. msProducts) the adapter will runSnippet() to load rows instead of its native SQL. Empty value falls back to the native adapter loader.';
$_lang['mse_prop_form_elementProperties'] = 'JSON object with properties forwarded to the element snippet (e.g. {"parents":0,"showZeroPrice":1}). Keys `resources` and `return` are always overridden by the adapter.';
$_lang['mse_prop_form_includeTVs'] = 'Comma-separated TV names to load into suggestions (e.g. subtitle,color). Appear as chunk placeholders, text TVs are highlighted.';
$_lang['mse_prop_form_tvPrefix'] = 'Prefix for TV placeholders (default empty — {$color}). Use a no-dot prefix (tv_) if a TV name clashes with a resource field: {$tv_color}.';
$_lang['mse_prop_form_processTVs'] = 'Comma-separated TVs to render through their output (media-source baseUrl for image/file, output filters). Only works together with includeTVs. Off by default.';
$_lang['mse_prop_form_prepareTVs'] = 'Comma-separated TVs to pre-process before output. Off by default.';
$_lang['mse_prop_pageId'] = 'ID of the search results page';
$_lang['mse_prop_autocomplete'] = 'Enable autocomplete';

// System settings
$_lang['area_mse_index'] = 'Indexing';
$_lang['area_mse_search'] = 'Search';
$_lang['area_mse_frontend'] = 'Frontend';

$_lang['setting_mse_index_min_word_length'] = 'Minimum word length';
$_lang['setting_mse_index_min_word_length_desc'] = 'Words shorter than this length will not be indexed.';

$_lang['setting_mse_index_split_words'] = 'Word split pattern (indexing)';
$_lang['setting_mse_index_split_words_desc'] = 'Regular expression to split text into words during indexing.';

$_lang['setting_mse_index_fields'] = 'Fields to index';
$_lang['setting_mse_index_fields_desc'] = 'List of resource fields with weights in format: pagetitle:3,longtitle:2,description:2,introtext:2,content:1';

$_lang['setting_mse_index_fields_product'] = 'Fields to index for msProduct';
$_lang['setting_mse_index_fields_product_desc'] = 'Same as mse_index_fields but for miniShop3 products. Supports article from msProductData.';

$_lang['setting_mse_suggest_min_query_length'] = 'Minimum autocomplete query length';
$_lang['setting_mse_suggest_min_query_length_desc'] = 'Number of characters required in a query before /search/suggest will respond. Shorter queries are ignored.';

$_lang['setting_mse_search_split_words'] = 'Word split pattern (search)';
$_lang['setting_mse_search_split_words_desc'] = 'Regular expression to split search query into words.';

$_lang['setting_mse_search_exact_match_bonus'] = 'Exact match bonus';
$_lang['setting_mse_search_exact_match_bonus_desc'] = 'Additional weight added to result for exact query match.';

$_lang['setting_mse_search_like_match_bonus'] = 'LIKE match bonus';
$_lang['setting_mse_search_like_match_bonus_desc'] = 'Additional weight for results found via LIKE search.';

$_lang['setting_mse_search_all_words_bonus'] = 'All words bonus';
$_lang['setting_mse_search_all_words_bonus_desc'] = 'Additional weight if all query words are found in document.';

$_lang['setting_mse_frontend_css'] = 'Frontend CSS';
$_lang['setting_mse_frontend_css_desc'] = 'URL of frontend stylesheet. Leave empty to disable.';

$_lang['setting_mse_frontend_js'] = 'Frontend JS';
$_lang['setting_mse_frontend_js_desc'] = 'URL of frontend scripts. Leave empty to disable.';

$_lang['setting_mse_use_scheduler'] = 'Use scheduler';
$_lang['setting_mse_use_scheduler_desc'] = 'Delayed indexing via MODX Scheduler when resources are saved.';

<?php
/**
 * mSearch Russian Lexicon
 */

$_lang['msearch'] = 'mSearch';
$_lang['mse_menu_desc'] = 'Полнотекстовый поиск с морфологическим анализом';

// Tabs
$_lang['mse_tab_search'] = 'Поиск';
$_lang['mse_tab_search_intro'] = 'Тестирование поисковых запросов';
$_lang['mse_tab_index'] = 'Индексация';
$_lang['mse_tab_index_intro'] = 'Управление поисковым индексом';
$_lang['mse_tab_queries'] = 'Запросы';
$_lang['mse_tab_queries_intro'] = 'Статистика поисковых запросов';
$_lang['mse_tab_aliases'] = 'Алиасы';
$_lang['mse_tab_aliases_intro'] = 'Синонимы и замены для поиска';
$_lang['mse_tab_dictionaries'] = 'Словари';
$_lang['mse_tab_dictionaries_intro'] = 'Управление морфологическими словарями';

// Index
$_lang['mse_index_total'] = 'Всего ресурсов';
$_lang['mse_index_indexed'] = 'Проиндексировано';
$_lang['mse_index_words'] = 'Слов в индексе';
$_lang['mse_index_limit'] = 'Порция';
$_lang['mse_index_offset'] = 'Смещение';
$_lang['mse_index_create'] = 'Создать индекс';
$_lang['mse_index_clear'] = 'Очистить индекс';
$_lang['mse_index_clear_confirm'] = 'Вы уверены, что хотите очистить весь поисковый индекс?';
$_lang['mse_indexing'] = 'Индексация...';
$_lang['mse_indexing_progress'] = 'Проиндексировано [[+indexed]] из [[+total]]';

// Queries
$_lang['mse_query'] = 'Запрос';
$_lang['mse_query_count'] = 'Количество';
$_lang['mse_query_results'] = 'Результатов';
$_lang['mse_query_found'] = 'Найдено';
$_lang['mse_query_created'] = 'Создан';
$_lang['mse_query_remove'] = 'Удалить';
$_lang['mse_query_remove_all'] = 'Удалить все';
$_lang['mse_query_remove_confirm'] = 'Вы уверены, что хотите удалить этот запрос?';
$_lang['mse_query_remove_all_confirm'] = 'Вы уверены, что хотите удалить всю статистику запросов?';

// Aliases
$_lang['mse_alias'] = 'Алиас';
$_lang['mse_alias_word'] = 'Слово';
$_lang['mse_alias_replacement'] = 'Замена';
$_lang['mse_alias_replace'] = 'Полная замена';
$_lang['mse_alias_replace_desc'] = 'Если включено, слово будет полностью заменено. Иначе замена будет добавлена как синоним.';
$_lang['mse_alias_active'] = 'Активен';
$_lang['mse_alias_create'] = 'Создать алиас';
$_lang['mse_alias_update'] = 'Редактировать алиас';
$_lang['mse_alias_remove'] = 'Удалить алиас';
$_lang['mse_alias_remove_confirm'] = 'Вы уверены, что хотите удалить этот алиас?';

// Dictionaries
$_lang['mse_dictionary'] = 'Словарь';
$_lang['mse_dictionary_language'] = 'Язык';
$_lang['mse_dictionary_installed'] = 'Установлен';
$_lang['mse_dictionary_install'] = 'Установить словарь';
$_lang['mse_dictionary_remove'] = 'Удалить словарь';
$_lang['mse_dictionary_mirror'] = 'Зеркало';
$_lang['mse_dictionary_mirror_select'] = 'Выберите зеркало для скачивания';
$_lang['mse_dictionary_downloading'] = 'Скачивание словаря...';

// Search preview
$_lang['mse_search_query'] = 'Поисковый запрос';
$_lang['mse_search_button'] = 'Найти';
$_lang['mse_search_results'] = 'Результаты поиска';
$_lang['mse_search_no_results'] = 'Ничего не найдено';
$_lang['mse_search_result_id'] = 'ID';
$_lang['mse_search_result_title'] = 'Заголовок';
$_lang['mse_search_result_weight'] = 'Вес';

// Errors
$_lang['mse_error'] = 'Ошибка';
$_lang['mse_vuetools_required'] = 'Для работы mSearch требуется пакет VueTools (>= 1.2.0). Установите или обновите его через Менеджер пакетов.';
$_lang['mse_err_query_required'] = 'Введите поисковый запрос';
$_lang['mse_err_word_required'] = 'Укажите слово';
$_lang['mse_err_alias_required'] = 'Укажите алиас';

// Common
$_lang['mse_yes'] = 'Да';
$_lang['mse_no'] = 'Нет';
$_lang['mse_confirm_accept'] = 'Да';
$_lang['mse_confirm_reject'] = 'Отмена';
$_lang['mse_cancel'] = 'Отмена';
$_lang['mse_save'] = 'Сохранить';
$_lang['mse_install'] = 'Установить';
$_lang['mse_replace'] = 'Замена';
$_lang['mse_add'] = 'Добавление';

// Frontend
$_lang['mse_search_placeholder'] = 'Поиск...';
$_lang['mse_weight'] = 'Релевантность';
$_lang['mse_results_found'] = 'Найдено результатов: [[+total]] по запросу "[[+query]]"';

// Snippet properties
$_lang['mse_prop_query'] = 'Поисковый запрос. По умолчанию берётся из $_REQUEST[queryVar]';
$_lang['mse_prop_queryVar'] = 'Имя HTTP-параметра с поисковым запросом (по умолчанию mse_query). Полезно для миграции или альтернативных форм.';
$_lang['mse_prop_tpl'] = 'Чанк для вывода одного результата';
$_lang['mse_prop_limit'] = 'Количество результатов на странице';
$_lang['mse_prop_offset'] = 'Смещение для пагинации';
$_lang['mse_prop_log'] = 'Записывать запрос в статистику поиска (логируется только первая страница)';
$_lang['mse_prop_outputSeparator'] = 'Разделитель между результатами';
$_lang['mse_prop_toPlaceholder'] = 'Имя плейсхолдера для вывода результатов';
$_lang['mse_prop_tplWrapper'] = 'Чанк-обёртка для всех результатов';
$_lang['mse_prop_form_tpl'] = 'Чанк формы поиска (legacy alias, оставлен для совместимости)';
$_lang['mse_prop_tplForm'] = 'Чанк формы поиска (по умолчанию mSearch.form)';
$_lang['mse_prop_form_suggest_tpl'] = 'Чанк строки подсказки автокомплита (по умолчанию mSearch.suggest.row)';
$_lang['mse_prop_form_suggest_limit'] = 'Максимум подсказок в автокомплите (по умолчанию 5)';
$_lang['mse_prop_form_ctx'] = 'Список контекстов через запятую для фильтрации поиска (по умолчанию — текущий контекст)';
$_lang['mse_prop_form_classKey'] = 'Список class_key через запятую для фильтрации поиска (по умолчанию — без фильтра, все классы). Например: MiniShop3\\Model\\msProduct';
$_lang['mse_prop_form_element'] = 'Имя внешнего сниппета (например msProducts), которым адаптер будет загружать строки подсказок вместо собственного SQL. Пусто — нативный загрузчик адаптера.';
$_lang['mse_prop_form_elementProperties'] = 'JSON-объект с параметрами, пробрасываемыми во внешний сниппет element (например {"parents":0,"showZeroPrice":1}). Ключи resources и return адаптер всегда переопределяет.';
$_lang['mse_prop_form_includeTVs'] = 'Список TV через запятую для подгрузки в подсказки (например subtitle,color). Появляются плейсхолдерами в чанке, текстовые подсвечиваются.';
$_lang['mse_prop_form_tvPrefix'] = 'Префикс для плейсхолдеров TV (по умолчанию пустой — {$color}). Задайте префикс без точки (tv_), если имя TV совпадает с полем ресурса: {$tv_color}.';
$_lang['mse_prop_form_processTVs'] = 'Список TV через запятую для обработки через рендер вывода (baseUrl медиа-источника для image/file, output-фильтры). Работает только совместно с includeTVs. По умолчанию выключено.';
$_lang['mse_prop_form_prepareTVs'] = 'Список TV через запятую для предобработки перед выводом. По умолчанию выключено.';
$_lang['mse_prop_pageId'] = 'ID страницы с результатами поиска';
$_lang['mse_prop_autocomplete'] = 'Включить автодополнение';

// System settings
$_lang['area_mse_index'] = 'Индексация';
$_lang['area_mse_search'] = 'Поиск';
$_lang['area_mse_frontend'] = 'Фронтенд';

$_lang['setting_mse_index_min_word_length'] = 'Минимальная длина слова';
$_lang['setting_mse_index_min_word_length_desc'] = 'Слова короче указанной длины не будут индексироваться.';

$_lang['setting_mse_index_split_words'] = 'Паттерн разделения слов (индексация)';
$_lang['setting_mse_index_split_words_desc'] = 'Регулярное выражение для разделения текста на слова при индексации.';

$_lang['setting_mse_index_fields'] = 'Поля для индексации';
$_lang['setting_mse_index_fields_desc'] = 'Список полей ресурса с весами в формате: pagetitle:3,longtitle:2,description:2,introtext:2,content:1';

$_lang['setting_mse_index_fields_product'] = 'Поля для индексации товаров msProduct';
$_lang['setting_mse_index_fields_product_desc'] = 'Аналогично mse_index_fields, но для товаров miniShop3. Поддерживается article из msProductData.';

$_lang['setting_mse_suggest_min_query_length'] = 'Минимальная длина запроса автокомплита';
$_lang['setting_mse_suggest_min_query_length_desc'] = 'Сколько символов должно быть в запросе, чтобы /search/suggest начал отвечать. Запросы короче — игнорируются.';

$_lang['setting_mse_search_split_words'] = 'Паттерн разделения слов (поиск)';
$_lang['setting_mse_search_split_words_desc'] = 'Регулярное выражение для разделения поискового запроса на слова.';

$_lang['setting_mse_search_exact_match_bonus'] = 'Бонус за точное совпадение';
$_lang['setting_mse_search_exact_match_bonus_desc'] = 'Дополнительный вес, добавляемый к результату при точном совпадении запроса.';

$_lang['setting_mse_search_like_match_bonus'] = 'Бонус за LIKE-совпадение';
$_lang['setting_mse_search_like_match_bonus_desc'] = 'Дополнительный вес для результатов, найденных через LIKE-поиск.';

$_lang['setting_mse_search_all_words_bonus'] = 'Бонус за все слова';
$_lang['setting_mse_search_all_words_bonus_desc'] = 'Дополнительный вес, если все слова запроса найдены в документе.';

$_lang['setting_mse_frontend_css'] = 'CSS фронтенда';
$_lang['setting_mse_frontend_css_desc'] = 'URL файла стилей для фронтенда. Оставьте пустым, чтобы отключить.';

$_lang['setting_mse_frontend_js'] = 'JS фронтенда';
$_lang['setting_mse_frontend_js_desc'] = 'URL файла скриптов для фронтенда. Оставьте пустым, чтобы отключить.';

$_lang['setting_mse_use_scheduler'] = 'Использовать планировщик';
$_lang['setting_mse_use_scheduler_desc'] = 'Отложенная индексация через MODX Scheduler при сохранении ресурсов.';

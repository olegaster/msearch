<?php

declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

final class InitialSchema extends AbstractMigration
{
    public function change(): void
    {
        // Table: mse_words - Word index
        $this->table('mse_words', [
            'id' => false,
            'primary_key' => ['resource', 'field', 'word', 'class_key'],
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_unicode_ci',
        ])
            ->addColumn('resource', 'integer', ['signed' => false, 'null' => false])
            ->addColumn('field', 'string', ['limit' => 50, 'null' => false])
            ->addColumn('word', 'string', ['limit' => 32, 'null' => false])
            ->addColumn('count', 'integer', ['signed' => false, 'null' => false, 'default' => 1])
            ->addColumn('class_key', 'string', ['limit' => 100, 'null' => false, 'default' => 'MODX\\Revolution\\modResource'])
            ->addIndex(['word'], ['name' => 'idx_word'])
            ->addIndex(['resource'], ['name' => 'idx_resource'])
            ->create();

        // Table: mse_intro - Full text for LIKE search and highlighting
        $this->table('mse_intro', [
            'id' => false,
            'primary_key' => ['resource', 'class_key'],
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_unicode_ci',
        ])
            ->addColumn('resource', 'integer', ['signed' => false, 'null' => false])
            ->addColumn('intro', 'text', ['limit' => \Phinx\Db\Adapter\MysqlAdapter::TEXT_MEDIUM, 'null' => false])
            ->addColumn('class_key', 'string', ['limit' => 100, 'null' => false, 'default' => 'MODX\\Revolution\\modResource'])
            ->addIndex(['resource'], ['name' => 'idx_resource'])
            ->create();

        // Table: mse_queries - Search statistics
        $this->table('mse_queries', [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_unicode_ci',
        ])
            ->addColumn('query', 'string', ['limit' => 255, 'null' => false])
            ->addColumn('count', 'integer', ['signed' => false, 'null' => false, 'default' => 1])
            ->addColumn('results', 'integer', ['signed' => false, 'null' => false, 'default' => 0])
            ->addColumn('found', 'boolean', ['null' => false, 'default' => true])
            ->addColumn('created_at', 'datetime', ['null' => false, 'default' => 'CURRENT_TIMESTAMP'])
            ->addColumn('updated_at', 'datetime', ['null' => true, 'update' => 'CURRENT_TIMESTAMP'])
            ->addIndex(['query'], ['name' => 'idx_query', 'unique' => true])
            ->addIndex(['count'], ['name' => 'idx_count'])
            ->create();

        // Table: mse_aliases - Synonyms and replacements
        $this->table('mse_aliases', [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_unicode_ci',
        ])
            ->addColumn('word', 'string', ['limit' => 100, 'null' => false])
            ->addColumn('alias', 'string', ['limit' => 100, 'null' => false])
            ->addColumn('replace', 'boolean', ['null' => false, 'default' => false])
            ->addColumn('active', 'boolean', ['null' => false, 'default' => true])
            ->addIndex(['word'], ['name' => 'idx_word'])
            ->addIndex(['active'], ['name' => 'idx_active'])
            ->create();
    }
}
